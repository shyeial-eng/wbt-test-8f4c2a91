const TAG = "marinara-capability-world-backstage-tracker";

const styleText = `
  :host { display: contents; color: var(--foreground); font-family: inherit; }
  .wbt-button { min-width: 2.25rem; max-width: 8.5rem; gap:.35rem; }
  .wbt-button-label { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:.68rem; }
  .wbt-popover { position:fixed; z-index:10030; width:min(34rem,calc(100vw - 1rem)); max-height:min(34rem,calc(100vh - 1rem)); overflow:auto; border:1px solid var(--border); border-radius:.8rem; background:color-mix(in srgb,var(--background) 95%,transparent); box-shadow:0 18px 45px rgba(0,0,0,.35); backdrop-filter:blur(14px); padding:.7rem; }
  .wbt-head { display:flex; align-items:center; justify-content:space-between; gap:.5rem; margin-bottom:.55rem; }
  .wbt-title { font-size:.78rem; font-weight:700; }
  .wbt-actions { display:flex; gap:.25rem; }
  .wbt-icon-button { border:1px solid var(--border); border-radius:.45rem; background:var(--secondary); color:var(--foreground); min-width:2rem; min-height:2rem; cursor:pointer; }
  .wbt-card { border:1px solid var(--border); border-radius:.65rem; background:color-mix(in srgb,var(--secondary) 55%,transparent); margin:.45rem 0; overflow:hidden; }
  .wbt-card summary { cursor:pointer; list-style:none; padding:.65rem .75rem; font-size:.72rem; font-weight:700; }
  .wbt-card summary::-webkit-details-marker { display:none; }
  .wbt-card pre { margin:0; border-top:1px solid var(--border); padding:.7rem .75rem; white-space:pre-wrap; overflow-wrap:anywhere; font:inherit; font-size:.7rem; line-height:1.55; color:var(--foreground); }
  .wbt-empty { padding:.85rem; color:var(--muted-foreground); font-size:.7rem; }
  .wbt-panel { position:relative; border:1px solid var(--border); border-radius:.8rem; overflow:hidden; background:color-mix(in srgb,var(--secondary) 30%,transparent); }
  .wbt-panel-head { display:flex; align-items:center; justify-content:space-between; gap:.5rem; padding:.65rem .75rem; }
  .wbt-updated { color:var(--muted-foreground); font-size:.6rem; }
  @media (max-width:767px) { .wbt-button-label { display:none; } .wbt-popover { left:.5rem!important; right:.5rem; width:auto; } }
`;

function escapeText(value) { return typeof value === "string" ? value : ""; }

async function latest(chatId) {
  const response = await fetch(`/api/world-backstage-tracker/latest/${encodeURIComponent(chatId)}`, { credentials: "same-origin" });
  if (!response.ok) throw new Error(`Tracker request failed (${response.status})`);
  return response.json();
}

class WorldBackstageElement extends HTMLElement {
  capabilityProps = {};
  capabilityRuntimeError = null;
  timer = null;
  state = null;
  open = false;
  connectedCallback() {
    this.addEventListener("marinara-capability-props", () => this.start());
    this.start();
  }
  disconnectedCallback() { if (this.timer) clearInterval(this.timer); this.timer = null; this.removePopover(); }
  async start() {
    if (this.timer) clearInterval(this.timer);
    await this.refresh();
    this.timer = setInterval(() => this.refresh(), 2500);
  }
  async refresh() {
    const chatId = this.capabilityProps?.chatId;
    if (!chatId || this.capabilityProps?.chatMode !== "roleplay") { this.replaceChildren(); return; }
    try { this.state = await latest(chatId); this.capabilityRuntimeError = null; this.render(); }
    catch (error) { this.capabilityRuntimeError = error instanceof Error ? error.message : String(error); this.render(); }
  }
  removePopover() { document.getElementById(`${TAG}-popover`)?.remove(); this.open = false; }
  makeDetails(title, content, open = true) {
    const details = document.createElement("details"); details.className = "wbt-card"; details.open = open;
    const summary = document.createElement("summary"); summary.textContent = title;
    const pre = document.createElement("pre"); pre.textContent = escapeText(content);
    details.append(summary, pre); return details;
  }
  showPopover(anchor) {
    this.removePopover(); this.open = true;
    const popover = document.createElement("div"); popover.id = `${TAG}-popover`; popover.className = "wbt-popover"; popover.setAttribute("data-chat-floating-panel", "");
    const style = document.createElement("style"); style.textContent = styleText; popover.append(style);
    const head = document.createElement("div"); head.className = "wbt-head";
    const title = document.createElement("strong"); title.className = "wbt-title"; title.textContent = "🌍 월드 비하인드";
    const actions = document.createElement("div"); actions.className = "wbt-actions";
    if (typeof this.capabilityProps?.onRerunTracker === "function") {
      const rerun = document.createElement("button"); rerun.className = "wbt-icon-button"; rerun.type = "button"; rerun.textContent = "↻"; rerun.title = "지금 갱신";
      rerun.onclick = () => this.capabilityProps.onRerunTracker(); actions.append(rerun);
    }
    const close = document.createElement("button"); close.className = "wbt-icon-button"; close.type = "button"; close.textContent = "×"; close.title = "닫기"; close.onclick = () => this.removePopover(); actions.append(close);
    head.append(title, actions); popover.append(head);
    if (this.state?.text) popover.append(this.makeDetails("🎭 동시 진행 상황", this.state.parallel), this.makeDetails("🌐 월드 상세정보", this.state.world));
    else { const empty = document.createElement("p"); empty.className = "wbt-empty"; empty.textContent = "아직 저장된 결과가 없습니다. RP를 진행하거나 갱신 버튼을 눌러주세요."; popover.append(empty); }
    document.body.append(popover);
    const rect = anchor.getBoundingClientRect(); const width = popover.offsetWidth; const height = popover.offsetHeight;
    popover.style.left = `${Math.max(8, Math.min(rect.left, innerWidth - width - 8))}px`;
    popover.style.top = `${Math.max(8, Math.min(rect.bottom + 5, innerHeight - height - 8))}px`;
  }
  renderToolbar() {
    const button = document.createElement("button"); button.type = "button";
    button.className = `${this.capabilityProps?.toolbarButtonClass || "mari-chrome-control mari-chrome-control--small"} wbt-button`;
    button.setAttribute("aria-label", "월드 비하인드 트래커"); button.innerHTML = `<span aria-hidden="true">🌍</span><span class="wbt-button-label">비하인드</span>`;
    button.onclick = () => this.open ? this.removePopover() : this.showPopover(button);
    this.append(button);
  }
  renderTracker() {
    const section = document.createElement("section"); section.className = "wbt-panel";
    const head = document.createElement("div"); head.className = "wbt-panel-head";
    const title = document.createElement("strong"); title.className = "wbt-title"; title.textContent = "🌍 월드 비하인드";
    const updated = document.createElement("span"); updated.className = "wbt-updated"; updated.textContent = this.state?.updatedAt ? new Date(this.state.updatedAt).toLocaleString() : "대기 중";
    head.append(title, updated); section.append(head);
    if (this.state?.text) section.append(this.makeDetails("🎭 동시 진행 상황", this.state.parallel), this.makeDetails("🌐 월드 상세정보", this.state.world));
    else { const empty = document.createElement("p"); empty.className = "wbt-empty"; empty.textContent = "아직 저장된 결과가 없습니다."; section.append(empty); }
    this.append(section);
  }
  render() {
    this.replaceChildren(); const style = document.createElement("style"); style.textContent = styleText; this.append(style);
    if (this.capabilityRuntimeError) { const p = document.createElement("p"); p.className = "wbt-empty"; p.textContent = "트래커 화면을 불러오지 못했습니다."; this.append(p); return; }
    const view = this.getAttribute("view"); if (view === "toolbar") this.renderToolbar(); else if (view === "tracker") this.renderTracker();
  }
}

if (!customElements.get(TAG)) customElements.define(TAG, WorldBackstageElement);
