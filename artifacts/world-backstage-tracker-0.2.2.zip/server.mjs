import { createHash } from "node:crypto";

const PACKAGE_ID = "world-backstage-tracker";
const DOCUMENT_KIND = "latest-output";
let runtime = null;
let ready = false;

function documentId(chatId) {
  return createHash("sha256").update(`${PACKAGE_ID}\0${DOCUMENT_KIND}\0${chatId}`).digest("hex");
}

function emptyState(chatId) {
  return { chatId, text: "", parallel: "", world: "", updatedAt: null };
}

function normalizeState(chatId, value) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  return {
    chatId,
    text: typeof source.text === "string" ? source.text.slice(0, 8000) : "",
    parallel: typeof source.parallel === "string" ? source.parallel.slice(0, 6000) : "",
    world: typeof source.world === "string" ? source.world.slice(0, 3000) : "",
    updatedAt: typeof source.updatedAt === "string" ? source.updatedAt : null,
  };
}

async function findState(chatId) {
  return runtime.persistence.documents.getById(PACKAGE_ID, documentId(chatId));
}

async function readState(chatId) {
  const document = await findState(chatId);
  return normalizeState(chatId, document?.data);
}

function isCreateConflict(error) {
  return Boolean(error && typeof error === "object" && error.code === "FILE_UNIQUE_CONSTRAINT");
}

async function writeState(chatId, state) {
  let conflict = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const document = await findState(chatId);
    const now = new Date().toISOString();
    const next = normalizeState(chatId, { ...state, updatedAt: now });
    if (!document) {
      try {
        await runtime.persistence.documents.create({
          id: documentId(chatId), packageId: PACKAGE_ID, kind: DOCUMENT_KIND,
          name: chatId, description: "Latest World Backstage Tracker output",
          data: next, createdAt: now, updatedAt: now,
        });
        return next;
      } catch (error) {
        conflict = error;
        if (!isCreateConflict(error)) throw error;
        continue;
      }
    }
    const saved = await runtime.persistence.documents.update({
      id: document.id, packageId: PACKAGE_ID, expectedRevision: document.revision,
      name: chatId, description: document.description, data: next, updatedAt: now,
    });
    if (saved) return next;
  }
  throw conflict instanceof Error ? conflict : new Error("Tracker state changed while saving.");
}

function parseOutput(value) {
  const raw = typeof value === "string" ? value : "";
  const cleaned = raw
    .replace(/```(?:text|markdown)?/gi, "")
    .replace(/```/g, "")
    .replace(/^\s*\[\/PARALLEL\]\s*$/gim, "")
    .replace(/^\s*\[\/WORLD\]\s*$/gim, "")
    .trim();
  const parallelStart = cleaned.search(/^\[PARALLEL\|[^\]\r\n]+\]\s*$/im);
  const worldStart = cleaned.search(/^\[WORLD\|[^\]\r\n]+\]\s*$/im);
  if (parallelStart < 0 || worldStart <= parallelStart) return null;
  const parallel = cleaned.slice(parallelStart, worldStart).trim();
  const world = cleaned.slice(worldStart).trim();
  if (!/^\[PARALLEL\|/i.test(parallel) || !/^\[WORLD\|/i.test(world)) return null;
  if (!/^-\s+.+:\s*.+/m.test(parallel) || !/^상세:\s*\S+/m.test(world)) return null;
  const text = `${parallel}\n\n${world}`.slice(0, 8000);
  return { text, parallel: parallel.slice(0, 6000), world: world.slice(0, 3000) };
}

function requiredChatId(value) {
  if (typeof value !== "string" || !value.trim() || value.length > 160) {
    throw Object.assign(new Error("Chat ID is required."), { statusCode: 400 });
  }
  return value.trim();
}

async function requireRoleplay(request) {
  const chatId = requiredChatId(request.params?.chatId);
  const chat = await runtime.persistence.getChat(chatId);
  if (!chat || chat.mode !== "roleplay") {
    throw Object.assign(new Error("World Backstage Tracker is available only in Roleplay chats."), { statusCode: 400 });
  }
}

const routes = async (app) => {
  app.get("/latest/:chatId", { preHandler: requireRoleplay }, async (request) => readState(requiredChatId(request.params.chatId)));
};

const agentRuntime = {
  async prepareContext({ context }) {
    if (context.chatMode !== "roleplay") return null;
    const previous = await readState(context.chatId);
    return previous.text ? { previousOutput: previous.text } : { previousOutput: null };
  },
  async finalizeResult({ context, result }) {
    if (!result.success) return result;
    const raw = typeof result.data === "string" ? result.data : result.data?.text;
    const parsed = parseOutput(raw);
    if (!parsed) {
      return { ...result, success: false, error: "Tracker output did not contain valid PARALLEL and WORLD sections." };
    }
    try {
      await writeState(context.chatId, parsed);
    } catch (error) {
      runtime.logger.warn("[world-backstage-tracker] Could not save output for %s: %s", context.chatId, error instanceof Error ? error.message : String(error));
      return { ...result, success: false, error: "Tracker output could not be saved." };
    }
    return { ...result, data: { text: parsed.text } };
  },
};

export async function activate({ api }) {
  runtime = api.runtime;
  const releases = [];
  try {
    releases.push(await api.registerPrivilegedRoutes(routes, { prefix: "/api/world-backstage-tracker" }));
    releases.push(api.registerService("agent-runtime:world-backstage-tracker", agentRuntime));
    ready = true;
    return () => {
      ready = false;
      while (releases.length) releases.pop()();
      runtime = null;
    };
  } catch (error) {
    while (releases.length) releases.pop()();
    runtime = null;
    throw error;
  }
}

export async function selfCheck() {
  if (!ready || !runtime) throw new Error("World Backstage Tracker did not initialize");
  await readState("__marinara_capability_self_check__");
}
