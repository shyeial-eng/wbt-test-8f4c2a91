const TAG = "marinara-capability-world-backstage-tracker";

const styleText = `
  :host { display: contents; color: var(--foreground); font-family: inherit; }
  .wbt-button { min-width: 2.25rem; max-width: 8.5rem; gap:.35rem; }
  .wbt-button-label { overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size:.68rem; }
  .wbt-popover { position:fixed; z-index:10030; width:min(34rem,calc(100vw - 1rem)); max-height:min(34rem,calc(100vh - 1rem)); overflow:auto; border:1px solid var(--border); border-radius:.8rem; background:color-mix(in srgb,var(--background) 95%,transparent); box-shadow:0 18px 45px rgba(0,0,0,.35); backdrop-filter:blur(14px); padding:.7rem; }
  .wbt-head { display:flex; align-items:center; justify-content:space-between; gap:.5rem; margin-bottom:.55rem; }
  .wbt-title { font-size:.78rem; font-weight:700; }
  .wbt-actions { display:flex; gap:.25rem; }
  .wbt-icon-button { border:1px solid var(--border); border-radius:.45rem; background:var(--secondary); color:var(--foreground); min-width:2rem; min-height:2rem; cursor:pointer; }
  .wbt-card { border-top:1px solid var(--border); background:transparent; margin:0; overflow:hidden; }
  .wbt-card summary { cursor:pointer; list-style:none; padding:.55rem .65rem; font-size:.69rem; font-weight:700; display:flex; justify-content:space-between; }
  .wbt-card summary::-webkit-details-marker { display:none; }
  .wbt-card pre { margin:0; border-top:1px solid var(--border); padding:.7rem .75rem; white-space:pre-wrap; overflow-wrap:anywhere; font:inherit; font-size:.7rem; line-height:1.55; color:var(--foreground); }
  .wbt-empty { padding:.85rem; color:var(--muted-foreground); font-size:.7rem; }
  .wbt-panel { position:relative; border:1px solid var(--border); border-radius:.8rem; overflow:hidden; background:color-mix(in srgb,var(--secondary) 30%,transparent); }
  .wbt-panel-head { display:flex; align-items:center; justify-content:space-between; gap:.5rem; padding:.65rem .75rem; }
  .wbt-updated { color:var(--muted-foreground); font-size:.6rem; }
  .wbt-group { border-top:1px solid var(--border); }
  .wbt-group-title { display:flex; align-items:center; justify-content:space-between; padding:.48rem .65rem; font-size:.67rem; color:var(--muted-foreground); }
  .wbt-list { display:grid; }
  .wbt-item { padding:.55rem .65rem; border-top:1px solid color-mix(in srgb,var(--border) 70%,transparent); }
  .wbt-item:first-child { border-top:0; }
  .wbt-item-title { font-size:.72rem; font-weight:700; margin-bottom:.22rem; }
  .wbt-item-body { white-space:pre-wrap; overflow-wrap:anywhere; font-size:.68rem; line-height:1.5; }
  .wbt-item-actions { display:flex; gap:.25rem; margin-top:.35rem; }
  .wbt-mini { border:0; background:transparent; color:var(--muted-foreground); cursor:pointer; min-width:1.65rem; min-height:1.45rem; padding:0; font-size:.72rem; }
  .wbt-mini:hover { color:var(--foreground); }
  .wbt-active { margin:.5rem; border:1px solid color-mix(in srgb,#5b7fd9 70%,var(--border)); border-radius:.65rem; overflow:hidden; }
  .wbt-active-note { margin:.5rem; padding:.48rem .55rem; border-radius:.45rem; background:var(--secondary); color:var(--muted-foreground); font-size:.61rem; line-height:1.45; }
  .wbt-status { min-height:1rem; padding:0 .65rem .35rem; color:var(--muted-foreground); font-size:.6rem; }
  @media (max-width:767px) { .wbt-button-label { display:none; } .wbt-popover { left:.5rem!important; right:.5rem; width:auto; } }
`;

function escapeText(value) { return typeof value === "string" ? value : ""; }

const latestCache = new Map();
const latestInFlight = new Map();
const CACHE_MS = 5000;

async function latest(chatId, force = false) {
  const cached = latestCache.get(chatId);
  if (!force && cached && Date.now() - cached.savedAt < CACHE_MS) return cached.value;
  if (latestInFlight.has(chatId)) return latestInFlight.get(chatId);
  const request = fetch(`/api/world-backstage-tracker/latest/${encodeURIComponent(chatId)}`, { credentials: "same-origin" })
    .then((response) => {
      if (!response.ok) throw new Error(`Tracker request failed (${response.status})`);
      return response.json();
    })
    .then((value) => {
      latestCache.set(chatId, { value, savedAt: Date.now() });
      return value;
    })
    .finally(() => latestInFlight.delete(chatId));
  latestInFlight.set(chatId, request);
  return request;
}

async function changeActive(chatId, method, payload, id = "") {
  const suffix = id ? `/${encodeURIComponent(id)}` : "";
  const response = await fetch(`/api/world-backstage-tracker/active/${encodeURIComponent(chatId)}${suffix}`, {
    method,
    credentials: "same-origin",
    headers: payload ? { "content-type": "application/json" } : undefined,
    body: payload ? JSON.stringify(payload) : undefined,
  });
  if (!response.ok) {
    const message = response.status === 409 ? "활성 서사는 최대 20개까지 저장할 수 있습니다." : `저장 요청 실패 (${response.status})`;
    throw new Error(message);
  }
  const value = await response.json();
  latestCache.set(chatId, { value, savedAt: Date.now() });
  return value;
}

class WorldBackstageElement extends HTMLElement {
  capabilityProps = {};
  capabilityRuntimeError = null;
  refreshTimer = null;
  lastChatId = null;
  lastRetryBusy = false;
  state = null;
  statusText = "";
  open = false;
  onProps = () => this.handleProps();
  connectedCallback() {
    this.addEventListener("marinara-capability-props", this.onProps);
    this.handleProps();
  }
  disconnectedCallback() {
    this.removeEventListener("marinara-capability-props", this.onProps);
    if (this.refreshTimer) clearTimeout(this.refreshTimer);
    this.refreshTimer = null;
    this.removePopover();
  }
  handleProps() {
    const chatId = this.capabilityProps?.chatId;
    const retryBusy = this.capabilityProps?.trackerRetryBusy === true;
    if (!chatId || this.capabilityProps?.chatMode !== "roleplay") {
      this.lastChatId = null; this.state = null; this.replaceChildren(); return;
    }
    if (chatId !== this.lastChatId) {
      this.lastChatId = chatId; this.state = null; this.capabilityRuntimeError = null;
      this.lastRetryBusy = retryBusy;
      void this.refresh(false); return;
    }
    if (this.lastRetryBusy && !retryBusy) void this.refresh(true);
    else this.scheduleRefresh();
    this.lastRetryBusy = retryBusy;
    this.render();
  }
  scheduleRefresh() {
    if (this.refreshTimer) clearTimeout(this.refreshTimer);
    this.refreshTimer = setTimeout(() => {
      this.refreshTimer = null;
      if (this.isConnected) void this.refresh(false);
    }, 1500);
  }
  async refresh(force = false) {
    const chatId = this.capabilityProps?.chatId;
    if (!chatId || this.capabilityProps?.chatMode !== "roleplay") return;
    try { this.state = await latest(chatId, force); this.capabilityRuntimeError = null; }
    catch (error) { this.capabilityRuntimeError = error instanceof Error ? error.message : String(error); }
    if (this.isConnected) this.render();
  }
  removePopover() { document.getElementById(`${TAG}-popover`)?.remove(); this.open = false; }
  makeDetails(title, content, open = true) {
    const details = document.createElement("details"); details.className = "wbt-card"; details.open = open;
    const summary = document.createElement("summary"); summary.textContent = title;
    const pre = document.createElement("pre"); pre.textContent = escapeText(content);
    details.append(summary, pre); return details;
  }
  displaySections() {
    if (Array.isArray(this.state?.sections) && this.state.sections.length) return this.state.sections;
    return [
      ...(this.state?.parallel ? [{ tag: "PARALLEL", fields: [], text: this.state.parallel }] : []),
      ...(this.state?.world ? [{ tag: "WORLD", fields: [], text: this.state.world }] : []),
    ];
  }
  sectionTitle(section) {
    if (section.tag === "PARALLEL") return "🎭 동시 진행 상황";
    if (section.tag === "WORLD") {
      const detail = Array.isArray(section.fields) ? section.fields.filter(Boolean).join(" · ") : "";
      return detail ? `🌐 월드 상세정보 · ${detail}` : "🌐 월드 상세정보";
    }
    const fields = Array.isArray(section.fields) ? section.fields.filter(Boolean) : [];
    return fields[0] || section.tag || "사용자 정의 섹션";
  }
  sectionItems(section) {
    const lines = escapeText(section?.content).split(/\r?\n/);
    const groups = [];
    let current = [];
    for (const line of lines) {
      if (/^\s*-\s+/.test(line)) {
        if (current.length) groups.push(current.join("\n"));
        current = [line.replace(/^\s*-\s+/, "")];
      } else if (line.trim() && current.length) current.push(line.trim());
    }
    if (current.length) groups.push(current.join("\n"));
    if (!groups.length && escapeText(section?.content).trim()) groups.push(escapeText(section.content).trim());
    return groups.slice(0, 30).map((body, index) => {
      const clean = body.replace(/\*\*/g, "").trim();
      const colon = clean.indexOf(":");
      const title = (colon > 0 ? clean.slice(0, colon) : `${this.sectionTitle(section)} ${index + 1}`).trim().slice(0, 120);
      return { title, body: clean };
    });
  }
  async activateItem(section, item) {
    const chatId = this.capabilityProps?.chatId;
    if (!chatId) return;
    try {
      this.statusText = "활성 서사에 추가하는 중…";
      this.state = await changeActive(chatId, "POST", { title: item.title, body: item.body, sourceTag: section.tag });
      this.statusText = "활성 서사에 추가했습니다.";
    } catch (error) { this.statusText = error instanceof Error ? error.message : String(error); }
    const anchor = this.querySelector(".wbt-button");
    if (this.open && anchor) this.showPopover(anchor, false); else this.render();
  }
  async removeActive(id) {
    const chatId = this.capabilityProps?.chatId;
    if (!chatId) return;
    try {
      this.statusText = "활성 서사를 종료하는 중…";
      this.state = await changeActive(chatId, "DELETE", null, id);
      this.statusText = "활성 서사를 종료했습니다.";
    } catch (error) { this.statusText = error instanceof Error ? error.message : String(error); }
    const anchor = this.querySelector(".wbt-button");
    if (this.open && anchor) this.showPopover(anchor, false); else this.render();
  }
  itemCard(section, item, active = false) {
    const card = document.createElement("article"); card.className = "wbt-item";
    const title = document.createElement("div"); title.className = "wbt-item-title"; title.textContent = item.title;
    const body = document.createElement("div"); body.className = "wbt-item-body"; body.textContent = item.body;
    const actions = document.createElement("div"); actions.className = "wbt-item-actions";
    const copy = document.createElement("button"); copy.type = "button"; copy.className = "wbt-mini"; copy.textContent = "⧉"; copy.title = "복사";
    copy.onclick = () => void navigator.clipboard?.writeText(item.body);
    const toggle = document.createElement("button"); toggle.type = "button"; toggle.className = "wbt-mini";
    toggle.textContent = active ? "⊖" : "⊕"; toggle.title = active ? "활성 서사 종료" : "활성 서사로 선택";
    toggle.onclick = () => active ? void this.removeActive(item.id) : void this.activateItem(section, item);
    actions.append(copy, toggle); card.append(title, body, actions); return card;
  }
  appendSections(parent) {
    for (const section of this.displaySections()) {
      const group = document.createElement("section"); group.className = "wbt-group";
      const head = document.createElement("div"); head.className = "wbt-group-title";
      const items = this.sectionItems(section);
      const label = document.createElement("span"); label.textContent = this.sectionTitle(section);
      const count = document.createElement("span"); count.textContent = String(items.length);
      head.append(label, count);
      const list = document.createElement("div"); list.className = "wbt-list";
      for (const item of items) list.append(this.itemCard(section, item));
      group.append(head, list); parent.append(group);
    }
  }
  appendActive(parent) {
    const items = Array.isArray(this.state?.activeNarratives) ? this.state.activeNarratives : [];
    const group = document.createElement("section"); group.className = "wbt-active";
    const head = document.createElement("div"); head.className = "wbt-group-title";
    const label = document.createElement("span"); label.textContent = "▣ 활성 서사";
    const count = document.createElement("span"); count.textContent = `${items.length} / 20`;
    head.append(label, count); group.append(head);
    if (!items.length) {
      const empty = document.createElement("div"); empty.className = "wbt-empty"; empty.textContent = "사건 카드의 ⊕를 눌러 활성 서사로 선택할 수 있습니다."; group.append(empty);
    } else {
      for (const item of items) group.append(this.itemCard({ tag: item.sourceTag }, item, true));
      const note = document.createElement("p"); note.className = "wbt-active-note";
      note.textContent = "활성 서사는 메인 RP에 숨은 참고정보로 전달됩니다. 종료하면 다음 전송부터 빠집니다."; group.append(note);
    }
    parent.append(group);
  }
  timelineText() {
    const runs = Array.isArray(this.state?.timeline) ? this.state.timeline : [];
    return runs.map((run, index) => {
      const items = Array.isArray(run?.items) ? run.items.filter((item) => typeof item === "string") : [];
      if (!items.length) return "";
      return `${index + 1}. ${items.join("\n   · ")}`;
    }).filter(Boolean).join("\n\n");
  }
  appendTimeline(parent) {
    const text = this.timelineText();
    if (text) parent.append(this.makeDetails("🕰 이전 사건 타임라인 · 최대 5회", text, false));
  }
  showPopover(anchor, refreshAfterOpen = true) {
    this.removePopover(); this.open = true;
    const popover = document.createElement("div"); popover.id = `${TAG}-popover`; popover.className = "wbt-popover"; popover.setAttribute("data-chat-floating-panel", "");
    const style = document.createElement("style"); style.textContent = styleText; popover.append(style);
    const head = document.createElement("div"); head.className = "wbt-head";
    const title = document.createElement("strong"); title.className = "wbt-title"; title.textContent = "🌍 월드 비하인드";
    const actions = document.createElement("div"); actions.className = "wbt-actions";
    if (typeof this.capabilityProps?.onRerunTracker === "function") {
      const rerun = document.createElement("button"); rerun.className = "wbt-icon-button"; rerun.type = "button"; rerun.textContent = "↻"; rerun.title = "지금 갱신";
      rerun.onclick = () => this.capabilityProps.onRerunTracker(); actions.append(rerun);
    }
    const close = document.createElement("button"); close.className = "wbt-icon-button"; close.type = "button"; close.textContent = "×"; close.title = "닫기"; close.onclick = () => this.removePopover(); actions.append(close);
    head.append(title, actions); popover.append(head);
    if (this.state?.text) { this.appendActive(popover); this.appendTimeline(popover); this.appendSections(popover); }
    else { const empty = document.createElement("p"); empty.className = "wbt-empty"; empty.textContent = "아직 저장된 결과가 없습니다. RP를 진행하거나 갱신 버튼을 눌러주세요."; popover.append(empty); }
    if (this.statusText) { const status = document.createElement("div"); status.className = "wbt-status"; status.textContent = this.statusText; popover.append(status); }
    document.body.append(popover);
    const rect = anchor.getBoundingClientRect(); const width = popover.offsetWidth; const height = popover.offsetHeight;
    popover.style.left = `${Math.max(8, Math.min(rect.left, innerWidth - width - 8))}px`;
    popover.style.top = `${Math.max(8, Math.min(rect.bottom + 5, innerHeight - height - 8))}px`;
    if (refreshAfterOpen) void this.refresh(true).then(() => {
      if (!this.open) return;
      const currentAnchor = this.querySelector(".wbt-button");
      if (currentAnchor) this.showPopover(currentAnchor, false);
    });
  }
  renderToolbar() {
    const button = document.createElement("button"); button.type = "button";
    button.className = `${this.capabilityProps?.toolbarButtonClass || "mari-chrome-control mari-chrome-control--small"} wbt-button`;
    button.setAttribute("aria-label", "월드 비하인드 트래커"); button.innerHTML = `<span aria-hidden="true">🌍</span><span class="wbt-button-label">비하인드</span>`;
    button.onclick = () => this.open ? this.removePopover() : this.showPopover(button);
    this.append(button);
  }
  renderTracker() {
    const section = document.createElement("section"); section.className = "wbt-panel";
    const head = document.createElement("div"); head.className = "wbt-panel-head";
    const title = document.createElement("strong"); title.className = "wbt-title"; title.textContent = "🌍 월드 비하인드";
    const updated = document.createElement("span"); updated.className = "wbt-updated"; updated.textContent = this.state?.updatedAt ? new Date(this.state.updatedAt).toLocaleString() : "대기 중";
    head.append(title, updated); section.append(head);
    if (this.state?.text) { this.appendActive(section); this.appendTimeline(section); this.appendSections(section); }
    else { const empty = document.createElement("p"); empty.className = "wbt-empty"; empty.textContent = "아직 저장된 결과가 없습니다."; section.append(empty); }
    if (this.statusText) { const status = document.createElement("div"); status.className = "wbt-status"; status.textContent = this.statusText; section.append(status); }
    this.append(section);
  }
  render() {
    this.replaceChildren(); const style = document.createElement("style"); style.textContent = styleText; this.append(style);
    const view = this.getAttribute("view"); if (view === "toolbar") this.renderToolbar(); else if (view === "tracker") this.renderTracker();
  }
}

if (!customElements.get(TAG)) customElements.define(TAG, WorldBackstageElement);
