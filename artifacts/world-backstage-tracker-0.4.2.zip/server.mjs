import { createHash } from "node:crypto";

const PACKAGE_ID = "world-backstage-tracker";
const DOCUMENT_KIND = "latest-output";
const TIMELINE_MAX_EVENTS = 5;
const TIMELINE_ITEM_MAX_CHARS = 220;
const ACTIVE_NARRATIVE_MAX = 20;
const ACTIVE_TITLE_MAX_CHARS = 120;
const ACTIVE_BODY_MAX_CHARS = 1200;
let runtime = null;
let ready = false;

function documentId(chatId) {
  return createHash("sha256").update(`${PACKAGE_ID}\0${DOCUMENT_KIND}\0${chatId}`).digest("hex");
}

function emptyState(chatId) {
  return { chatId, text: "", parallel: "", world: "", sections: [], timeline: [], activeNarratives: [], updatedAt: null };
}

function cleanSingleLine(value, max) {
  return typeof value === "string" ? value.replace(/\s+/g, " ").trim().slice(0, max) : "";
}

function normalizeActiveNarratives(value) {
  if (!Array.isArray(value)) return [];
  const seen = new Set();
  return value.slice(-ACTIVE_NARRATIVE_MAX).flatMap((entry) => {
    if (!entry || typeof entry !== "object" || Array.isArray(entry)) return [];
    const id = cleanSingleLine(entry.id, 80);
    const title = cleanSingleLine(entry.title, ACTIVE_TITLE_MAX_CHARS);
    const body = typeof entry.body === "string" ? entry.body.trim().slice(0, ACTIVE_BODY_MAX_CHARS) : "";
    if (!id || !title || !body || seen.has(id)) return [];
    seen.add(id);
    return [{
      id,
      title,
      body,
      sourceTag: cleanSingleLine(entry.sourceTag, 32) || "EVENT",
      createdAt: typeof entry.createdAt === "string" ? entry.createdAt : null,
    }];
  });
}

function compactTimelineItem(value) {
  return typeof value === "string" ? value.replace(/^\s*-\s*/, "").replace(/\s+/g, " ").trim().slice(0, TIMELINE_ITEM_MAX_CHARS) : "";
}

function timelineEventKey(value) {
  const body = compactTimelineItem(value).replace(/^\[PARALLEL\]\s*/i, "");
  const subject = (body.split(/[:：]/, 1)[0] || body.slice(0, 80))
    .replace(/[*_`~]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLocaleLowerCase();
  return subject || body.toLocaleLowerCase();
}

function timelineEvent(value, at = null, fallbackId = "timeline-event") {
  const compact = compactTimelineItem(value);
  if (!compact) return null;
  const tagged = /^\[([A-Z][A-Z0-9_-]*)\]\s*(.*)$/s.exec(compact);
  if (tagged && tagged[1] !== "PARALLEL") return null;
  const body = compactTimelineItem(tagged ? tagged[2] : compact);
  const eventKey = timelineEventKey(body);
  if (!body || !eventKey) return null;
  return {
    id: `event-${createHash("sha256").update(eventKey).digest("hex").slice(0, 20)}` || fallbackId,
    eventKey,
    at: typeof at === "string" ? at : null,
    items: [`[PARALLEL] ${body}`.slice(0, TIMELINE_ITEM_MAX_CHARS)],
  };
}

function normalizeTimeline(value) {
  if (!Array.isArray(value)) return [];
  const events = new Map();
  value.forEach((run, index) => {
    if (!run || typeof run !== "object" || Array.isArray(run)) return [];
    for (const item of Array.isArray(run.items) ? run.items : []) {
      const event = timelineEvent(item, run.at, `timeline-${index}`);
      if (!event) continue;
      events.delete(event.eventKey);
      events.set(event.eventKey, event);
    }
  });
  return [...events.values()].slice(-TIMELINE_MAX_EVENTS);
}

function timelineEventsFromParsed(parsed, at = new Date().toISOString()) {
  return (Array.isArray(parsed?.sections) ? parsed.sections : []).flatMap((section) => {
    const tag = typeof section?.tag === "string" ? section.tag.toUpperCase() : "";
    if (tag !== "PARALLEL") return [];
    const lines = typeof section?.content === "string" ? section.content.split(/\r?\n/) : [];
    const bullets = lines.filter((line) => /^\s*-\s+/.test(line));
    const candidates = bullets.length ? bullets : [section?.content];
    return candidates.map((line, index) => timelineEvent(line, at, `event-${index}`)).filter(Boolean);
  }).slice(0, 3);
}

function appendTimeline(existing, parsed, at = new Date().toISOString()) {
  const events = new Map(normalizeTimeline(existing).map((event) => [event.eventKey, event]));
  for (const event of timelineEventsFromParsed(parsed, at)) {
    events.delete(event.eventKey);
    events.set(event.eventKey, event);
  }
  return [...events.values()].slice(-TIMELINE_MAX_EVENTS);
}

function removeLegacyCurrentRun(timeline, sections) {
  if (!timeline.length) return timeline;
  const parallel = sections.find((section) => section.tag === "PARALLEL");
  if (!parallel) return timeline;
  const currentKeys = new Set(parallel.content.split(/\r?\n/)
    .filter((line) => /^\s*-\s+/.test(line))
    .map(timelineEventKey).filter(Boolean).slice(0, 3));
  return timeline.filter((event) => !currentKeys.has(event.eventKey));
}

function timelineContext(timeline) {
  const runs = normalizeTimeline(timeline);
  if (!runs.length) return null;
  const lines = ["[RECENT OFFSCREEN TIMELINE — 이어질 가치가 있는 최근 사건 최대 5개]"];
  runs.forEach((event, index) => {
    lines.push(`${index + 1}. ${event.items[0]}`);
  });
  return lines.join("\n");
}

function normalizeState(chatId, value) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  const sections = Array.isArray(source.sections)
    ? source.sections.slice(0, 12).flatMap((section, index) => {
        if (!section || typeof section !== "object" || Array.isArray(section)) return [];
        const tag = typeof section.tag === "string" ? section.tag.slice(0, 32) : "";
        const header = typeof section.header === "string" ? section.header.slice(0, 300) : "";
        const content = typeof section.content === "string" ? section.content.slice(0, 6000) : "";
        const text = typeof section.text === "string" ? section.text.slice(0, 7000) : "";
        const fields = Array.isArray(section.fields)
          ? section.fields.slice(0, 6).filter((field) => typeof field === "string").map((field) => field.slice(0, 120))
          : [];
        if (!tag || !header || !content || !text) return [];
        return [{ id: `${tag.toLowerCase()}-${index}`, tag, header, fields, content, text }];
      })
    : [];
  const timeline = removeLegacyCurrentRun(normalizeTimeline(source.timeline), sections);
  return {
    chatId,
    text: typeof source.text === "string" ? source.text.slice(0, 8000) : "",
    parallel: typeof source.parallel === "string" ? source.parallel.slice(0, 6000) : "",
    world: typeof source.world === "string" ? source.world.slice(0, 3000) : "",
    sections,
    timeline,
    activeNarratives: normalizeActiveNarratives(source.activeNarratives),
    updatedAt: typeof source.updatedAt === "string" ? source.updatedAt : null,
  };
}

async function findState(chatId) {
  return runtime.persistence.documents.getById(PACKAGE_ID, documentId(chatId));
}

async function readState(chatId) {
  const document = await findState(chatId);
  return normalizeState(chatId, document?.data);
}

function isCreateConflict(error) {
  return Boolean(error && typeof error === "object" && error.code === "FILE_UNIQUE_CONSTRAINT");
}

async function writeState(chatId, state) {
  let conflict = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const document = await findState(chatId);
    const now = new Date().toISOString();
    const next = normalizeState(chatId, { ...state, updatedAt: now });
    if (!document) {
      try {
        await runtime.persistence.documents.create({
          id: documentId(chatId), packageId: PACKAGE_ID, kind: DOCUMENT_KIND,
          name: chatId, description: "Latest World Backstage Tracker output",
          data: next, createdAt: now, updatedAt: now,
        });
        return next;
      } catch (error) {
        conflict = error;
        if (!isCreateConflict(error)) throw error;
        continue;
      }
    }
    const saved = await runtime.persistence.documents.update({
      id: document.id, packageId: PACKAGE_ID, expectedRevision: document.revision,
      name: chatId, description: document.description, data: next, updatedAt: now,
    });
    if (saved) return next;
  }
  throw conflict instanceof Error ? conflict : new Error("Tracker state changed while saving.");
}

function parseOutput(value) {
  const raw = typeof value === "string" ? value : "";
  const cleaned = raw
    .replace(/```(?:text|markdown)?/gi, "")
    .replace(/```/g, "")
    .replace(/^\s*\[\/[A-Z][A-Z0-9_-]{0,31}\]\s*$/gim, "")
    .trim();
  if (!cleaned || cleaned.length > 20000) return null;
  const headerPattern = /^\[([A-Z][A-Z0-9_-]{0,31})\|([^\]\r\n]+)\]\s*$/gim;
  const matches = [...cleaned.matchAll(headerPattern)];
  if (matches.length < 2 || matches.length > 12) return null;
  if (cleaned.slice(0, matches[0].index).trim()) return null;

  const seen = new Set();
  const sections = [];
  for (let index = 0; index < matches.length; index += 1) {
    const match = matches[index];
    const tag = match[1].toUpperCase();
    if (seen.has(tag)) return null;
    seen.add(tag);
    const fields = match[2].split("|").map((field) => field.trim());
    if (fields.length < 2 || fields.length > 6 || fields.some((field) => !field)) return null;
    const start = match.index;
    const contentStart = start + match[0].length;
    const end = index + 1 < matches.length ? matches[index + 1].index : cleaned.length;
    const content = cleaned.slice(contentStart, end).trim();
    if (!content) return null;
    const header = `[${tag}|${fields.join("|")}]`;
    const text = `${header}\n${content}`;
    sections.push({ id: `${tag.toLowerCase()}-${index}`, tag, header, fields, content, text });
  }

  const parallelSection = sections.find((section) => section.tag === "PARALLEL");
  const worldSection = sections.find((section) => section.tag === "WORLD");
  if (!parallelSection || !worldSection) return null;
  if (!/^-\s+.+:\s*.+/m.test(parallelSection.content) || !/^상세:\s*\S+/m.test(worldSection.content)) return null;

  const text = sections.map((section) => section.text).join("\n\n").slice(0, 8000);
  return {
    text,
    parallel: parallelSection.text.slice(0, 6000),
    world: worldSection.text.slice(0, 3000),
    sections,
  };
}

function requiredChatId(value) {
  if (typeof value !== "string" || !value.trim() || value.length > 160) {
    throw Object.assign(new Error("Chat ID is required."), { statusCode: 400 });
  }
  return value.trim();
}

async function requireRoleplay(request) {
  const chatId = requiredChatId(request.params?.chatId);
  const chat = await runtime.persistence.getChat(chatId);
  if (!chat || chat.mode !== "roleplay") {
    throw Object.assign(new Error("World Backstage Tracker is available only in Roleplay chats."), { statusCode: 400 });
  }
}

function activeNarrativeId(chatId, sourceTag, title, body) {
  return createHash("sha256").update(`${chatId}\0${sourceTag}\0${title}\0${body}`).digest("hex").slice(0, 32);
}

function activeNarrativePrompt(items) {
  const active = normalizeActiveNarratives(items);
  if (!active.length) return null;
  return [
    "[WBT ACTIVE NARRATIVES — 사용자 선택 활성 서사]",
    "아래 항목은 앞으로 자연스럽게 이어갈 수 있는 서사 소재다.",
    "확정된 사건, 캐릭터의 자동 지식, USER가 이미 선택하거나 행동한 내용으로 취급하지 않는다.",
    "현재 장면과 정사에 맞을 때만 낮은 강도로 활용하며 USER의 선택을 대신 결정하지 않는다.",
    ...active.map((item, index) => `${index + 1}. ${item.title}\n${item.body}`),
  ].join("\n");
}

const routes = async (app) => {
  app.get("/latest/:chatId", { preHandler: requireRoleplay }, async (request) => readState(requiredChatId(request.params.chatId)));
  app.post("/active/:chatId", { preHandler: requireRoleplay }, async (request) => {
    const chatId = requiredChatId(request.params.chatId);
    const body = request.body && typeof request.body === "object" && !Array.isArray(request.body) ? request.body : {};
    const title = cleanSingleLine(body.title, ACTIVE_TITLE_MAX_CHARS);
    const text = typeof body.body === "string" ? body.body.trim().slice(0, ACTIVE_BODY_MAX_CHARS) : "";
    const sourceTag = cleanSingleLine(body.sourceTag, 32) || "EVENT";
    if (!title || !text) throw Object.assign(new Error("Narrative title and body are required."), { statusCode: 400 });
    const previous = await readState(chatId);
    const id = activeNarrativeId(chatId, sourceTag, title, text);
    if (!previous.activeNarratives.some((item) => item.id === id)) {
      if (previous.activeNarratives.length >= ACTIVE_NARRATIVE_MAX) {
        throw Object.assign(new Error("Active narrative limit reached (20)."), { statusCode: 409 });
      }
      previous.activeNarratives.push({ id, title, body: text, sourceTag, createdAt: new Date().toISOString() });
      await writeState(chatId, previous);
    }
    return readState(chatId);
  });
  app.delete("/active/:chatId/:id", { preHandler: requireRoleplay }, async (request) => {
    const chatId = requiredChatId(request.params.chatId);
    const id = cleanSingleLine(request.params?.id, 80);
    const previous = await readState(chatId);
    const next = previous.activeNarratives.filter((item) => item.id !== id);
    if (next.length !== previous.activeNarratives.length) await writeState(chatId, { ...previous, activeNarratives: next });
    return readState(chatId);
  });
};

const agentRuntime = {
  async prepareContext({ context }) {
    if (context.chatMode !== "roleplay") return null;
    const previous = await readState(context.chatId);
    return {
      previousOutput: previous.text || null,
      recentTimeline: timelineContext(previous.timeline),
    };
  },
  async finalizeResult({ context, result }) {
    if (!result.success) return result;
    const raw = typeof result.data === "string" ? result.data : result.data?.text;
    const parsed = parseOutput(raw);
    if (!parsed) {
      return { ...result, success: false, error: "Tracker output did not contain valid PARALLEL and WORLD sections." };
    }
    try {
      const previous = await readState(context.chatId);
      await writeState(context.chatId, {
        ...parsed,
        timeline: previous.text ? appendTimeline(previous.timeline, previous) : previous.timeline,
        activeNarratives: previous.activeNarratives,
      });
    } catch (error) {
      runtime.logger.warn("[world-backstage-tracker] Could not save output for %s: %s", context.chatId, error instanceof Error ? error.message : String(error));
      return { ...result, success: false, error: "Tracker output could not be saved." };
    }
    return { ...result, data: { text: parsed.text } };
  },
};

export async function activate({ api }) {
  runtime = api.runtime;
  const releases = [];
  try {
    releases.push(await api.registerPrivilegedRoutes(routes, { prefix: "/api/world-backstage-tracker" }));
    releases.push(api.registerService("agent-runtime:world-backstage-tracker", agentRuntime));
    if (typeof api.registerPromptContext === "function") {
      releases.push(api.registerPromptContext(async ({ chatId, mode }) => {
        if (mode !== "roleplay") return null;
        const state = await readState(chatId);
        return activeNarrativePrompt(state.activeNarratives);
      }));
    }
    ready = true;
    return () => {
      ready = false;
      while (releases.length) releases.pop()();
      runtime = null;
    };
  } catch (error) {
    while (releases.length) releases.pop()();
    runtime = null;
    throw error;
  }
}

export async function selfCheck() {
  if (!ready || !runtime) throw new Error("World Backstage Tracker did not initialize");
  await readState("__marinara_capability_self_check__");
}

export const __timelineTestApi = Object.freeze({
  normalizeTimeline,
  appendTimeline,
  removeLegacyCurrentRun,
  timelineContext,
});
