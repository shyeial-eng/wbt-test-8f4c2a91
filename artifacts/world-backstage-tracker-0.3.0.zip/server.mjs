import { createHash } from "node:crypto";

const PACKAGE_ID = "world-backstage-tracker";
const DOCUMENT_KIND = "latest-output";
let runtime = null;
let ready = false;

function documentId(chatId) {
  return createHash("sha256").update(`${PACKAGE_ID}\0${DOCUMENT_KIND}\0${chatId}`).digest("hex");
}

function emptyState(chatId) {
  return { chatId, text: "", parallel: "", world: "", sections: [], updatedAt: null };
}

function normalizeState(chatId, value) {
  const source = value && typeof value === "object" && !Array.isArray(value) ? value : {};
  const sections = Array.isArray(source.sections)
    ? source.sections.slice(0, 12).flatMap((section, index) => {
        if (!section || typeof section !== "object" || Array.isArray(section)) return [];
        const tag = typeof section.tag === "string" ? section.tag.slice(0, 32) : "";
        const header = typeof section.header === "string" ? section.header.slice(0, 300) : "";
        const content = typeof section.content === "string" ? section.content.slice(0, 6000) : "";
        const text = typeof section.text === "string" ? section.text.slice(0, 7000) : "";
        const fields = Array.isArray(section.fields)
          ? section.fields.slice(0, 6).filter((field) => typeof field === "string").map((field) => field.slice(0, 120))
          : [];
        if (!tag || !header || !content || !text) return [];
        return [{ id: `${tag.toLowerCase()}-${index}`, tag, header, fields, content, text }];
      })
    : [];
  return {
    chatId,
    text: typeof source.text === "string" ? source.text.slice(0, 8000) : "",
    parallel: typeof source.parallel === "string" ? source.parallel.slice(0, 6000) : "",
    world: typeof source.world === "string" ? source.world.slice(0, 3000) : "",
    sections,
    updatedAt: typeof source.updatedAt === "string" ? source.updatedAt : null,
  };
}

async function findState(chatId) {
  return runtime.persistence.documents.getById(PACKAGE_ID, documentId(chatId));
}

async function readState(chatId) {
  const document = await findState(chatId);
  return normalizeState(chatId, document?.data);
}

function isCreateConflict(error) {
  return Boolean(error && typeof error === "object" && error.code === "FILE_UNIQUE_CONSTRAINT");
}

async function writeState(chatId, state) {
  let conflict = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    const document = await findState(chatId);
    const now = new Date().toISOString();
    const next = normalizeState(chatId, { ...state, updatedAt: now });
    if (!document) {
      try {
        await runtime.persistence.documents.create({
          id: documentId(chatId), packageId: PACKAGE_ID, kind: DOCUMENT_KIND,
          name: chatId, description: "Latest World Backstage Tracker output",
          data: next, createdAt: now, updatedAt: now,
        });
        return next;
      } catch (error) {
        conflict = error;
        if (!isCreateConflict(error)) throw error;
        continue;
      }
    }
    const saved = await runtime.persistence.documents.update({
      id: document.id, packageId: PACKAGE_ID, expectedRevision: document.revision,
      name: chatId, description: document.description, data: next, updatedAt: now,
    });
    if (saved) return next;
  }
  throw conflict instanceof Error ? conflict : new Error("Tracker state changed while saving.");
}

function parseOutput(value) {
  const raw = typeof value === "string" ? value : "";
  const cleaned = raw
    .replace(/```(?:text|markdown)?/gi, "")
    .replace(/```/g, "")
    .replace(/^\s*\[\/[A-Z][A-Z0-9_-]{0,31}\]\s*$/gim, "")
    .trim();
  if (!cleaned || cleaned.length > 20000) return null;
  const headerPattern = /^\[([A-Z][A-Z0-9_-]{0,31})\|([^\]\r\n]+)\]\s*$/gim;
  const matches = [...cleaned.matchAll(headerPattern)];
  if (matches.length < 2 || matches.length > 12) return null;
  if (cleaned.slice(0, matches[0].index).trim()) return null;

  const seen = new Set();
  const sections = [];
  for (let index = 0; index < matches.length; index += 1) {
    const match = matches[index];
    const tag = match[1].toUpperCase();
    if (seen.has(tag)) return null;
    seen.add(tag);
    const fields = match[2].split("|").map((field) => field.trim());
    if (fields.length < 2 || fields.length > 6 || fields.some((field) => !field)) return null;
    const start = match.index;
    const contentStart = start + match[0].length;
    const end = index + 1 < matches.length ? matches[index + 1].index : cleaned.length;
    const content = cleaned.slice(contentStart, end).trim();
    if (!content) return null;
    const header = `[${tag}|${fields.join("|")}]`;
    const text = `${header}\n${content}`;
    sections.push({ id: `${tag.toLowerCase()}-${index}`, tag, header, fields, content, text });
  }

  const parallelSection = sections.find((section) => section.tag === "PARALLEL");
  const worldSection = sections.find((section) => section.tag === "WORLD");
  if (!parallelSection || !worldSection) return null;
  if (!/^-\s+.+:\s*.+/m.test(parallelSection.content) || !/^상세:\s*\S+/m.test(worldSection.content)) return null;

  const text = sections.map((section) => section.text).join("\n\n").slice(0, 8000);
  return {
    text,
    parallel: parallelSection.text.slice(0, 6000),
    world: worldSection.text.slice(0, 3000),
    sections,
  };
}

function requiredChatId(value) {
  if (typeof value !== "string" || !value.trim() || value.length > 160) {
    throw Object.assign(new Error("Chat ID is required."), { statusCode: 400 });
  }
  return value.trim();
}

async function requireRoleplay(request) {
  const chatId = requiredChatId(request.params?.chatId);
  const chat = await runtime.persistence.getChat(chatId);
  if (!chat || chat.mode !== "roleplay") {
    throw Object.assign(new Error("World Backstage Tracker is available only in Roleplay chats."), { statusCode: 400 });
  }
}

const routes = async (app) => {
  app.get("/latest/:chatId", { preHandler: requireRoleplay }, async (request) => readState(requiredChatId(request.params.chatId)));
};

const agentRuntime = {
  async prepareContext({ context }) {
    if (context.chatMode !== "roleplay") return null;
    const previous = await readState(context.chatId);
    return previous.text ? { previousOutput: previous.text } : { previousOutput: null };
  },
  async finalizeResult({ context, result }) {
    if (!result.success) return result;
    const raw = typeof result.data === "string" ? result.data : result.data?.text;
    const parsed = parseOutput(raw);
    if (!parsed) {
      return { ...result, success: false, error: "Tracker output did not contain valid PARALLEL and WORLD sections." };
    }
    try {
      await writeState(context.chatId, parsed);
    } catch (error) {
      runtime.logger.warn("[world-backstage-tracker] Could not save output for %s: %s", context.chatId, error instanceof Error ? error.message : String(error));
      return { ...result, success: false, error: "Tracker output could not be saved." };
    }
    return { ...result, data: { text: parsed.text } };
  },
};

export async function activate({ api }) {
  runtime = api.runtime;
  const releases = [];
  try {
    releases.push(await api.registerPrivilegedRoutes(routes, { prefix: "/api/world-backstage-tracker" }));
    releases.push(api.registerService("agent-runtime:world-backstage-tracker", agentRuntime));
    ready = true;
    return () => {
      ready = false;
      while (releases.length) releases.pop()();
      runtime = null;
    };
  } catch (error) {
    while (releases.length) releases.pop()();
    runtime = null;
    throw error;
  }
}

export async function selfCheck() {
  if (!ready || !runtime) throw new Error("World Backstage Tracker did not initialize");
  await readState("__marinara_capability_self_check__");
}
