import { createQuestInstance } from "./domain/quest-domain.mjs";
import { acceptOpportunity, addHistoryRecord, createHistoryRecord, createOpportunity, projectSecretQuest, transitionOpportunity, transitionSecretVisibility } from "./features/quest-lifecycle.mjs";
import { createRpContextAdapter } from "./integration/rp-context-adapter.mjs";
import { createQuestStateStore } from "./persistence/quest-state-store.mjs";
import { markEffectApplied, processRuntimeEvent } from "./runtime/quest-runtime.mjs";
import { chooseTheme, createThemeRegistry } from "./themes/theme-registry.mjs";
import { createQuestViewModel } from "./ui/quest-view-model.mjs";

const PACKAGE_ID = "world-backstage-quest-engine";
const registry = createThemeRegistry();
const rpAdapter = createRpContextAdapter({ confidenceThreshold: 0.8, characterBudget: 2000 });
let runtime = null;
let store = null;
let ready = false;

function requiredChatId(value) {
  if (typeof value !== "string" || !value.trim() || value.length > 160) throw Object.assign(new Error("Chat ID is required."), { statusCode: 400 });
  return value.trim();
}

async function requireRoleplay(request) {
  const chatId = requiredChatId(request.params?.chatId);
  const chat = await runtime.persistence.getChat(chatId);
  if (!chat || chat.mode !== "roleplay") throw Object.assign(new Error("WBT Quest Engine is available only in Roleplay chats."), { statusCode: 400 });
  return chatId;
}

function parsePayload(result) {
  const raw = typeof result?.data === "string" ? result.data : typeof result?.data?.text === "string" ? result.data.text : result?.data;
  if (raw && typeof raw === "object" && !Array.isArray(raw)) return raw;
  if (typeof raw !== "string" || raw.length > 30000) return null;
  try { const parsed = JSON.parse(raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/, "")); return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : null; }
  catch { return null; }
}

function definitionsForState(state) {
  const pack = registry.get(state.selectedTheme || "custom") ?? registry.get("custom");
  return pack?.quests ?? [];
}

function findDefinition(state, id) { return definitionsForState(state).find((definition) => definition.id === id) ?? null; }

function publicView(state, revision, errors = {}) {
  const definitions = definitionsForState(state);
  const byId = new Map(definitions.map((definition) => [definition.id, definition]));
  const secrets = new Map((state.secretStates ?? []).map((secret) => [secret.definitionId, secret]));
  const quests = state.questInstances.flatMap((instance) => {
    const definition = byId.get(instance.definitionId); if (!definition) return [];
    const projected = projectSecretQuest(definition, instance, secrets.get(definition.id));
    return [{ key: instance.instanceId, title: projected.title, summary: projected.summary, visibility: projected.visibility, status: instance.status, theme: definition.themeId, npc: instance.sourceNpcId ?? "", objectives: projected.objectives.map((objective) => ({ title: definition.objectives.find((item) => item.id === objective.id)?.title ?? "목표", completed: objective.completed })) }];
  });
  const opportunities = state.opportunities.map((entry) => ({ key: entry.opportunityId, title: byId.get(entry.questDefinitionId)?.title ?? "새로운 기회", reason: entry.reason, status: entry.status, expiresAt: entry.expiresAt }));
  const pack = registry.get(state.selectedTheme || "custom");
  const events = Object.entries(state.eventState ?? {}).map(([eventId, entry]) => ({ key: eventId, title: pack?.events?.find((event) => event.id === eventId)?.title ?? "이벤트", status: entry.status, period: entry.evaluatedAt ?? "" }));
  const history = state.historyRecords.map((entry) => ({ key: entry.recordId, title: entry.snapshot.title, outcome: entry.outcome, occurredAt: entry.occurredAt, epilogue: entry.epilogue.text }));
  const availableThemes = registry.list().map((entry) => ({ id: entry.metadata.id, name: entry.metadata.name }));
  return { ...createQuestViewModel({ activeTab: state.uiPreferences.activeTab, selectedTheme: state.selectedTheme, availableThemes, quests, opportunities, events, history, updatedAt: state.updatedAt, ...errors }), revision };
}

function updateSecrets(state, definitions, now) {
  const rules = registry.get(state.selectedTheme || "custom")?.secretRules ?? [];
  for (const rule of rules) {
    const instance = state.questInstances.find((item) => item.definitionId === rule.questDefinitionId); if (!instance) continue;
    const progress = Object.values(instance.objectiveProgress ?? {}).reduce((total, item) => total + (Number(item.value) || 0), 0);
    let secret = state.secretStates.find((item) => item.definitionId === rule.questDefinitionId);
    if (!secret) { secret = { definitionId: rule.questDefinitionId, visibility: "hidden", hintedAt: null, revealedAt: null }; state.secretStates.push(secret); }
    const reveal = progress >= (rule.revealAfterProgress ?? Infinity);
    const hint = progress >= (rule.hintAfterProgress ?? Infinity);
    const next = reveal ? transitionSecretVisibility(secret, "revealed", now) : hint ? transitionSecretVisibility(secret, "hinted", now) : null;
    if (next?.changed) state.secretStates[state.secretStates.indexOf(secret)] = next.secretState;
  }
}

async function processAgentPayload(context, payload) {
  const loaded = await store.load(context.chatId);
  if (loaded.readOnly) return { saved: false, reason: loaded.reason, state: loaded.state };
  const state = loaded.state;
  if (!state.selectedTheme || state.selectedTheme === "auto") state.selectedTheme = chooseTheme({ tags: payload.themeTags }, registry).themeId;
  const definitions = definitionsForState(state);
  const signals = rpAdapter.finalizeSignals(payload, state);
  state.processedEventIds = signals.processedEventIds;
  for (const offer of (Array.isArray(payload.offers) ? payload.offers : []).slice(0, 20)) {
    const definition = findDefinition(state, offer?.definitionId); if (!definition) continue;
    const id = typeof offer.offerId === "string" ? offer.offerId : null;
    if (!id || state.opportunities.some((entry) => entry.opportunityId === id)) continue;
    try { state.opportunities.push(createOpportunity({ opportunityId: id, questDefinitionId: definition.id, source: "agent", reason: offer.reason, confidence: offer.confidence }, new Date().toISOString())); } catch {}
  }
  for (const candidate of signals.opportunityCandidates) {
    const definition = findDefinition(state, candidate.event.target); if (!definition || state.opportunities.some((entry) => entry.opportunityId === candidate.candidateId)) continue;
    state.opportunities.push(createOpportunity({ opportunityId: candidate.candidateId, questDefinitionId: definition.id, source: "low-confidence", reason: candidate.reason, confidence: candidate.confidence }, candidate.event.occurredAt));
  }
  for (const event of signals.events) {
    for (let index = 0; index < state.questInstances.length; index += 1) {
      const instance = state.questInstances[index]; const definition = definitions.find((item) => item.id === instance.definitionId); if (!definition) continue;
      const processed = processRuntimeEvent(definition, instance, event, {}); if (!processed.changed) continue;
      let next = processed.instance;
      for (const effect of processed.effects) { const marked = markEffectApplied(next, effect.effectId); if (marked.changed) { next = marked.instance; state.appliedEffectIds = [...new Set([...state.appliedEffectIds, effect.effectId])].slice(-1000); } }
      state.questInstances[index] = next;
      if (processed.completed) { const history = createHistoryRecord(definition, next, event.occurredAt, definition.epilogue); if (history.created) state.historyRecords = addHistoryRecord(state.historyRecords, history.record).history; }
    }
  }
  updateSecrets(state, definitions, new Date().toISOString());
  return store.save(context.chatId, state, { expectedRevision: loaded.revision });
}

const routes = async (app) => {
  app.get("/view/:chatId", { preHandler: requireRoleplay }, async (request) => { const loaded = await store.load(requiredChatId(request.params.chatId)); return publicView(loaded.state, loaded.revision, loaded.readOnly ? { runtimeError: "지원하지 않는 저장 버전입니다." } : {}); });
  app.post("/command/:chatId", { preHandler: requireRoleplay }, async (request, reply) => {
    const chatId = requiredChatId(request.params.chatId); const body = request.body && typeof request.body === "object" ? request.body : {};
    if (!["select-tab", "set-theme", "accept-opportunity", "dismiss-opportunity"].includes(body.action) || typeof body.key !== "string" || body.key.length > 160) return reply.code(400).send({ error: "Invalid command." });
    const loaded = await store.load(chatId); if (loaded.readOnly) return reply.code(409).send({ error: "State is read-only." });
    if (body.expectedRevision !== undefined && body.expectedRevision !== loaded.revision) return reply.code(409).send({ error: "State changed. Refresh and try again." });
    const state = loaded.state;
    if (body.action === "select-tab") state.uiPreferences.activeTab = body.key;
    else if (body.action === "set-theme") {
      if (!registry.has(body.key)) return reply.code(400).send({ error: "Unknown theme." });
      state.selectedTheme = body.key;
    }
    else {
      const index = state.opportunities.findIndex((entry) => entry.opportunityId === body.key); if (index < 0) return reply.code(404).send({ error: "Opportunity not found." });
      const opportunity = state.opportunities[index];
      if (body.action === "dismiss-opportunity") { const changed = transitionOpportunity(opportunity, "dismissed", new Date().toISOString()); if (!changed.changed) return reply.code(409).send({ error: "Opportunity cannot be dismissed." }); state.opportunities[index] = changed.opportunity; }
      else { const definition = findDefinition(state, opportunity.questDefinitionId); if (!definition) return reply.code(409).send({ error: "Quest definition is unavailable." }); const accepted = acceptOpportunity(opportunity, definition, { instanceId: `${definition.id}.${Date.now().toString(36)}`, now: new Date().toISOString() }); if (!accepted.changed) return reply.code(409).send({ error: "Opportunity cannot be accepted." }); state.opportunities[index] = accepted.opportunity; state.questInstances.push(accepted.instance); }
    }
    const saved = await store.save(chatId, state, { expectedRevision: loaded.revision }); if (!saved.saved) return reply.code(409).send({ error: saved.reason });
    const refreshed = await store.load(chatId); return publicView(refreshed.state, refreshed.revision);
  });
};

const agentRuntime = {
  async prepareContext({ context }) { if (context.chatMode !== "roleplay") return null; const loaded = await store.load(context.chatId); return rpAdapter.prepareContext({ state: loaded.state, definitions: definitionsForState(loaded.state), secretStates: loaded.state.secretStates, pendingEpilogues: loaded.state.historyRecords.map((entry) => entry.epilogue) }); },
  async finalizeResult({ context, result }) { if (!result.success || context.chatMode !== "roleplay") return result; const payload = parsePayload(result); if (!payload) return { ...result, success: false, error: "WBT output was not valid structured JSON." }; const saved = await processAgentPayload(context, payload); if (!saved.saved) return { ...result, success: false, error: `WBT state could not be saved (${saved.reason}).` }; return { ...result, data: { text: buildSummary(saved.state) } }; },
};

function buildSummary(state) { return rpAdapter.prepareContext({ state, definitions: definitionsForState(state), secretStates: state.secretStates, pendingEpilogues: state.historyRecords.map((entry) => entry.epilogue) }).questContext; }

export async function activate({ api }) {
  runtime = api.runtime; store = createQuestStateStore({ packageId: PACKAGE_ID, documents: runtime.persistence.documents, logger: runtime.logger }); const releases = [];
  try { releases.push(await api.registerPrivilegedRoutes(routes, { prefix: `/api/${PACKAGE_ID}` })); releases.push(api.registerService(`agent-runtime:${PACKAGE_ID}`, agentRuntime)); ready = true; return () => { ready = false; while (releases.length) releases.pop()(); store = null; runtime = null; }; }
  catch (error) { while (releases.length) releases.pop()(); store = null; runtime = null; throw error; }
}

export async function selfCheck() { if (!ready || !store) throw new Error("WBT Quest Engine did not initialize"); await store.load("__wbt_quest_engine_self_check__"); }
