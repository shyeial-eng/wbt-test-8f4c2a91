const TABS = Object.freeze([
  { id: "now", label: "지금" },
  { id: "quests", label: "퀘스트" },
  { id: "opportunities", label: "기회" },
  { id: "events", label: "이벤트" },
  { id: "history", label: "기록" },
]);

function object(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function text(value, limit = 300) {
  return typeof value === "string" ? value.replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, limit) : "";
}

function items(value, limit = 250) {
  return Array.isArray(value) ? value.slice(0, limit).map((entry) => object(entry)) : [];
}

function questCard(entry) {
  const visibility = ["hidden", "hinted", "revealed"].includes(entry.visibility) ? entry.visibility : "revealed";
  if (visibility === "hidden") return null;
  return {
    key: text(entry.key || entry.instanceId, 120),
    title: visibility === "hinted" ? "숨겨진 퀘스트" : text(entry.title, 160) || "이름 없는 퀘스트",
    summary: visibility === "hinted" ? "특별한 사건의 단서가 보입니다." : text(entry.summary, 500),
    status: text(entry.status, 40),
    theme: text(entry.theme, 80),
    npc: text(entry.npc, 120),
    objectives: visibility === "hinted" ? [] : items(entry.objectives, 30).map((objective) => ({ title: text(objective.title, 160), completed: objective.completed === true })),
  };
}

export function createQuestViewModel(value) {
  const source = object(value);
  const quests = items(source.quests).map(questCard).filter(Boolean);
  const opportunities = items(source.opportunities, 150).map((entry) => ({
    key: text(entry.key || entry.opportunityId, 120), title: text(entry.title, 160) || "새로운 기회", reason: text(entry.reason, 500), status: text(entry.status, 40), expiresAt: text(entry.expiresAt, 40),
  }));
  const events = items(source.events, 100).map((entry) => ({ key: text(entry.key || entry.eventId, 120), title: text(entry.title, 160) || "이벤트", status: text(entry.status, 40), period: text(entry.period, 120) }));
  const history = items(source.history, 500).map((entry) => ({ key: text(entry.key || entry.recordId, 120), title: text(entry.title, 160) || "완료 기록", outcome: text(entry.outcome, 40), occurredAt: text(entry.occurredAt, 40), epilogue: text(entry.epilogue, 1000) }));
  const activeQuests = quests.filter((entry) => ["accepted", "active", "blocked"].includes(entry.status));
  const availableThemes = items(source.availableThemes, 20)
    .map((entry) => ({ id: text(entry.id, 80), name: text(entry.name, 120) }))
    .filter((entry) => entry.id && entry.name);
  return {
    tabs: TABS.map((tab) => ({ ...tab })),
    activeTab: TABS.some((tab) => tab.id === source.activeTab) ? source.activeTab : "now",
    selectedTheme: text(source.selectedTheme, 80) || "선택 안 됨",
    availableThemes,
    saving: source.saving === true,
    saveError: text(source.saveError, 500),
    runtimeError: text(source.runtimeError, 500),
    updatedAt: text(source.updatedAt, 40),
    now: { quests: activeQuests.slice(0, 5), opportunities: opportunities.filter((entry) => ["new", "viewed"].includes(entry.status)).slice(0, 3), events: events.filter((entry) => entry.status === "active").slice(0, 3) },
    quests,
    opportunities,
    events,
    history,
  };
}

export { TABS as questViewTabs };
