const QUEST_KINDS = new Set(["main", "side", "npc", "opportunity", "secret", "seasonal", "event"]);
const COMPLETION_POLICIES = new Set(["all", "any", "ordered", "scoreThreshold"]);
const PROGRESS_MODES = new Set(["increment", "set", "boolean", "threshold", "checklist"]);
const VISIBILITY_POLICIES = new Set(["visible", "hinted", "hidden"]);
const REPEAT_POLICIES = new Set(["once", "repeatable", "cooldown", "perSeason", "perEvent"]);
const QUEST_STATUSES = new Set(["available", "offered", "accepted", "active", "blocked", "completed", "failed", "expired", "archived"]);
const ID_PATTERN = /^[a-z0-9]+(?:[._-][a-z0-9]+)*$/;

const ALLOWED_TRANSITIONS = Object.freeze({
  available: new Set(["offered", "accepted", "active", "expired", "archived"]),
  offered: new Set(["available", "accepted", "expired", "archived"]),
  accepted: new Set(["active", "blocked", "failed", "expired", "archived"]),
  active: new Set(["blocked", "completed", "failed", "expired", "archived"]),
  blocked: new Set(["active", "failed", "expired", "archived"]),
  completed: new Set(["archived"]),
  failed: new Set(["archived"]),
  expired: new Set(["archived"]),
  archived: new Set(),
});

export function isStableId(value) {
  return typeof value === "string" && value.length <= 120 && ID_PATTERN.test(value);
}

function issue(path, message) {
  return { path, message };
}

function validateObjective(objective, path, seenIds) {
  const issues = [];
  if (!objective || typeof objective !== "object" || Array.isArray(objective)) return [issue(path, "목표는 객체여야 합니다.")];
  if (!isStableId(objective.id)) issues.push(issue(`${path}.id`, "안정적인 소문자 ID가 필요합니다."));
  else if (seenIds.has(objective.id)) issues.push(issue(`${path}.id`, "같은 퀘스트에서 목표 ID가 중복되었습니다."));
  else seenIds.add(objective.id);
  if (typeof objective.type !== "string" || !objective.type.trim()) issues.push(issue(`${path}.type`, "목표 종류가 필요합니다."));
  if (!PROGRESS_MODES.has(objective.progressMode)) issues.push(issue(`${path}.progressMode`, "지원하지 않는 진행 방식입니다."));
  if (objective.requiredCount !== undefined && (!Number.isFinite(objective.requiredCount) || objective.requiredCount <= 0)) {
    issues.push(issue(`${path}.requiredCount`, "필요 횟수는 0보다 큰 숫자여야 합니다."));
  }
  return issues;
}

export function validateQuestDefinition(value) {
  const issues = [];
  if (!value || typeof value !== "object" || Array.isArray(value)) return { valid: false, issues: [issue("quest", "퀘스트 정의는 객체여야 합니다.")] };
  for (const key of ["id", "themeId"]) if (!isStableId(value[key])) issues.push(issue(key, "안정적인 소문자 ID가 필요합니다."));
  if (!Number.isInteger(value.schemaVersion) || value.schemaVersion < 1) issues.push(issue("schemaVersion", "1 이상의 스키마 버전이 필요합니다."));
  for (const key of ["title", "summary", "description"]) if (typeof value[key] !== "string" || !value[key].trim()) issues.push(issue(key, "비어 있지 않은 문장이 필요합니다."));
  if (!QUEST_KINDS.has(value.kind)) issues.push(issue("kind", "지원하지 않는 퀘스트 종류입니다."));
  if (!COMPLETION_POLICIES.has(value.completionPolicy)) issues.push(issue("completionPolicy", "지원하지 않는 완료 정책입니다."));
  if (!VISIBILITY_POLICIES.has(value.visibilityPolicy)) issues.push(issue("visibilityPolicy", "지원하지 않는 공개 정책입니다."));
  if (!REPEAT_POLICIES.has(value.repeatPolicy)) issues.push(issue("repeatPolicy", "지원하지 않는 반복 정책입니다."));
  if (!Array.isArray(value.objectives) || value.objectives.length === 0) issues.push(issue("objectives", "목표가 하나 이상 필요합니다."));
  else {
    const seenIds = new Set();
    value.objectives.forEach((objective, index) => issues.push(...validateObjective(objective, `objectives[${index}]`, seenIds)));
  }
  return { valid: issues.length === 0, issues };
}

export function validateThemePack(value) {
  const issues = [];
  if (!value || typeof value !== "object" || Array.isArray(value)) return { valid: false, issues: [issue("theme", "테마 팩은 객체여야 합니다.")] };
  if (!isStableId(value.metadata?.id)) issues.push(issue("metadata.id", "안정적인 테마 ID가 필요합니다."));
  for (const key of ["name", "version", "description"]) if (typeof value.metadata?.[key] !== "string" || !value.metadata[key].trim()) issues.push(issue(`metadata.${key}`, "비어 있지 않은 값이 필요합니다."));
  if (!Array.isArray(value.quests)) issues.push(issue("quests", "퀘스트 목록이 필요합니다."));
  else {
    const questIds = new Set();
    value.quests.forEach((quest, index) => {
      const result = validateQuestDefinition(quest);
      issues.push(...result.issues.map((entry) => issue(`quests[${index}].${entry.path}`, entry.message)));
      if (isStableId(quest?.id) && questIds.has(quest.id)) issues.push(issue(`quests[${index}].id`, "테마 팩에서 퀘스트 ID가 중복되었습니다."));
      if (isStableId(quest?.id)) questIds.add(quest.id);
      if (quest?.themeId !== value.metadata?.id) issues.push(issue(`quests[${index}].themeId`, "퀘스트의 themeId가 테마 팩 ID와 다릅니다."));
    });
  }
  return { valid: issues.length === 0, issues };
}

export function createQuestInstance(definition, options = {}) {
  const validation = validateQuestDefinition(definition);
  if (!validation.valid) throw new TypeError(`유효하지 않은 퀘스트 정의: ${validation.issues[0].path}`);
  const now = options.now ?? new Date().toISOString();
  const instanceId = options.instanceId;
  if (!isStableId(instanceId)) throw new TypeError("안정적인 퀘스트 인스턴스 ID가 필요합니다.");
  return {
    instanceId,
    definitionId: definition.id,
    definitionVersion: definition.contentVersion ?? "1",
    status: options.status ?? "available",
    objectiveProgress: Object.fromEntries(definition.objectives.map((objective) => [objective.id, { value: 0, completed: false }])),
    discoveredAt: now,
    offeredAt: null,
    acceptedAt: null,
    updatedAt: now,
    completedAt: null,
    runtimeFlags: {},
    appliedEventIds: [],
    appliedEffectIds: [],
    snapshot: { title: definition.title, summary: definition.summary },
  };
}

export function transitionQuest(instance, nextStatus, occurredAt) {
  if (!QUEST_STATUSES.has(instance?.status) || !QUEST_STATUSES.has(nextStatus)) throw new TypeError("알 수 없는 퀘스트 상태입니다.");
  if (!ALLOWED_TRANSITIONS[instance.status].has(nextStatus)) return { changed: false, reason: "illegal-transition", instance };
  const next = { ...instance, status: nextStatus, updatedAt: occurredAt };
  if (nextStatus === "offered") next.offeredAt = occurredAt;
  if (nextStatus === "accepted" || nextStatus === "active") next.acceptedAt ??= occurredAt;
  if (nextStatus === "completed") next.completedAt = occurredAt;
  return { changed: true, instance: next };
}

export function applyObjectiveEvent(definition, instance, event) {
  if (!isStableId(event?.eventId)) return { changed: false, reason: "invalid-event-id", instance };
  if (instance.appliedEventIds.includes(event.eventId)) return { changed: false, reason: "duplicate-event", instance };
  if (!["accepted", "active"].includes(instance.status)) return { changed: false, reason: "inactive-quest", instance };
  if (!["all", "any"].includes(definition.completionPolicy)) return { changed: false, reason: "unsupported-completion-policy", instance };
  let changed = false;
  const objectiveProgress = structuredClone(instance.objectiveProgress);
  for (const objective of definition.objectives) {
    if (objective.type !== event.type || (objective.target !== undefined && objective.target !== event.target)) continue;
    if (!["increment", "set", "boolean", "threshold"].includes(objective.progressMode)) {
      return { changed: false, reason: "unsupported-progress-mode", instance };
    }
    const current = objectiveProgress[objective.id] ?? { value: 0, completed: false };
    const amount = Number.isFinite(event.amount) ? event.amount : 1;
    const value = objective.progressMode === "set" ? amount : objective.progressMode === "boolean" ? 1 : current.value + amount;
    const required = objective.requiredCount ?? 1;
    objectiveProgress[objective.id] = { value, completed: value >= required };
    changed = true;
  }
  if (!changed) return { changed: false, reason: "no-matching-objective", instance };
  const completionValues = definition.objectives.filter((objective) => !objective.optional).map((objective) => objectiveProgress[objective.id]?.completed === true);
  const complete = definition.completionPolicy === "any" ? completionValues.some(Boolean) : completionValues.every(Boolean);
  const next = {
    ...instance,
    status: complete ? "completed" : "active",
    objectiveProgress,
    appliedEventIds: [...instance.appliedEventIds, event.eventId].slice(-500),
    updatedAt: event.occurredAt,
    completedAt: complete ? event.occurredAt : instance.completedAt,
  };
  return { changed: true, completed: complete, instance: next };
}

export const questDomainConstants = Object.freeze({
  questKinds: [...QUEST_KINDS],
  questStatuses: [...QUEST_STATUSES],
  completionPolicies: [...COMPLETION_POLICIES],
});
