import { isStableId } from "../domain/quest-domain.mjs";

const EVENT_TYPES = new Set([
  "activityCompleted", "itemAcquired", "locationVisited", "npcInteraction",
  "relationshipChanged", "statChanged", "flagChanged", "timeChanged",
  "questChanged", "custom",
]);
const OPERATORS = new Set(["eq", "neq", "gt", "gte", "lt", "lte", "includes", "hasTag"]);

function clone(value) {
  return structuredClone(value);
}

export function normalizeRuntimeEvent(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return { valid: false, issues: ["사건은 객체여야 합니다."] };
  const issues = [];
  if (!isStableId(value.eventId)) issues.push("eventId는 안정적인 소문자 ID여야 합니다.");
  if (!EVENT_TYPES.has(value.type)) issues.push("지원하지 않는 사건 종류입니다.");
  if (typeof value.occurredAt !== "string" || Number.isNaN(Date.parse(value.occurredAt))) issues.push("올바른 occurredAt 시간이 필요합니다.");
  if (value.amount !== undefined && !Number.isFinite(value.amount)) issues.push("amount는 유한한 숫자여야 합니다.");
  if (value.tags !== undefined && (!Array.isArray(value.tags) || value.tags.some((tag) => typeof tag !== "string"))) issues.push("tags는 문자열 목록이어야 합니다.");
  if (issues.length) return { valid: false, issues };
  return {
    valid: true,
    event: {
      eventId: value.eventId,
      type: value.type,
      occurredAt: value.occurredAt,
      source: typeof value.source === "string" ? value.source.slice(0, 80) : "unknown",
      actorId: typeof value.actorId === "string" ? value.actorId.slice(0, 120) : null,
      target: typeof value.target === "string" ? value.target.slice(0, 120) : null,
      amount: Number.isFinite(value.amount) ? value.amount : 1,
      value: value.value,
      tags: Array.isArray(value.tags) ? [...new Set(value.tags.slice(0, 30).map((tag) => tag.slice(0, 80)))] : [],
      metadata: value.metadata && typeof value.metadata === "object" && !Array.isArray(value.metadata) ? clone(value.metadata) : {},
      turnId: typeof value.turnId === "string" ? value.turnId.slice(0, 120) : null,
      sessionId: typeof value.sessionId === "string" ? value.sessionId.slice(0, 120) : null,
    },
  };
}

function readField(subject, path) {
  if (typeof path !== "string" || !path || path.includes("__proto__") || path.includes("constructor") || path.includes("prototype")) return undefined;
  return path.split(".").reduce((current, key) => current && typeof current === "object" ? current[key] : undefined, subject);
}

export function evaluateCondition(condition, context) {
  if (!condition || typeof condition !== "object" || !OPERATORS.has(condition.operator)) return { valid: false, matched: false };
  const actual = readField(context, condition.field);
  const expected = condition.value;
  let matched = false;
  switch (condition.operator) {
    case "eq": matched = actual === expected; break;
    case "neq": matched = actual !== expected; break;
    case "gt": matched = typeof actual === "number" && actual > expected; break;
    case "gte": matched = typeof actual === "number" && actual >= expected; break;
    case "lt": matched = typeof actual === "number" && actual < expected; break;
    case "lte": matched = typeof actual === "number" && actual <= expected; break;
    case "includes": matched = (Array.isArray(actual) || typeof actual === "string") && actual.includes(expected); break;
    case "hasTag": matched = Array.isArray(actual) && actual.includes(expected); break;
  }
  return { valid: true, matched };
}

function conditionsMatch(conditions, context) {
  if (conditions === undefined) return true;
  if (!Array.isArray(conditions)) return false;
  return conditions.every((condition) => evaluateCondition(condition, context).matched);
}

function objectiveMatches(objective, event, context) {
  if (objective.type !== event.type) return false;
  if (objective.target !== undefined && objective.target !== event.target) return false;
  return conditionsMatch(objective.conditions, { event, state: context });
}

function advanceObjective(objective, progress, event) {
  const current = progress ?? { value: 0, completed: false, checked: [] };
  const required = objective.requiredCount ?? objective.requiredValue ?? 1;
  if (objective.progressMode === "checklist") {
    const item = typeof event.value === "string" ? event.value : event.target;
    const checked = [...new Set([...(current.checked ?? []), item].filter(Boolean))];
    const requiredItems = Array.isArray(objective.requiredItems) ? objective.requiredItems : [];
    return { value: checked.length, checked, completed: requiredItems.length > 0 && requiredItems.every((entry) => checked.includes(entry)) };
  }
  const value = objective.progressMode === "set" || objective.progressMode === "threshold"
    ? Number(event.value ?? event.amount)
    : objective.progressMode === "boolean"
      ? 1
      : current.value + event.amount;
  return { value, completed: value >= required };
}

function questIsComplete(definition, progress) {
  const required = definition.objectives.filter((objective) => !objective.optional);
  if (definition.completionPolicy === "any") return required.some((objective) => progress[objective.id]?.completed === true);
  if (definition.completionPolicy === "scoreThreshold") {
    const score = required.reduce((total, objective) => total + (Number(progress[objective.id]?.value) || 0), 0);
    return score >= (definition.scoreThreshold ?? 1);
  }
  return required.every((objective) => progress[objective.id]?.completed === true);
}

function nextOrderedObjective(definition, progress) {
  return definition.objectives.find((objective) => !objective.optional && progress[objective.id]?.completed !== true)?.id ?? null;
}

function pendingEffects(definition, instance) {
  const applied = new Set(instance.appliedEffectIds ?? []);
  return (Array.isArray(definition.rewards) ? definition.rewards : []).flatMap((effect, index) => {
    const effectId = typeof effect?.id === "string" && effect.id ? effect.id : `${definition.id}.reward.${index}`;
    return applied.has(effectId) ? [] : [{ ...clone(effect), effectId }];
  });
}

export function processRuntimeEvent(definition, instance, rawEvent, context = {}) {
  const normalized = normalizeRuntimeEvent(rawEvent);
  if (!normalized.valid) return { changed: false, reason: "invalid-event", issues: normalized.issues, instance, effects: [] };
  const event = normalized.event;
  if ((instance.appliedEventIds ?? []).includes(event.eventId)) return { changed: false, reason: "duplicate-event", instance, effects: [] };
  if (!["accepted", "active"].includes(instance.status)) return { changed: false, reason: "inactive-quest", instance, effects: [] };
  if (!conditionsMatch(definition.prerequisites, { event, state: context })) return { changed: false, reason: "prerequisites-not-met", instance, effects: [] };

  const progress = clone(instance.objectiveProgress);
  const orderedId = definition.completionPolicy === "ordered" ? nextOrderedObjective(definition, progress) : null;
  let changed = false;
  for (const objective of definition.objectives) {
    if (orderedId && objective.id !== orderedId) continue;
    if (!objectiveMatches(objective, event, context)) continue;
    progress[objective.id] = advanceObjective(objective, progress[objective.id], event);
    changed = true;
    if (definition.completionPolicy === "ordered") break;
  }
  if (!changed) return { changed: false, reason: "no-matching-objective", instance, effects: [] };

  const completed = questIsComplete(definition, progress);
  const next = {
    ...instance,
    status: completed ? "completed" : "active",
    objectiveProgress: progress,
    appliedEventIds: [...(instance.appliedEventIds ?? []), event.eventId].slice(-500),
    updatedAt: event.occurredAt,
    completedAt: completed ? event.occurredAt : instance.completedAt,
  };
  return { changed: true, completed, instance: next, effects: completed ? pendingEffects(definition, next) : [] };
}

export function markEffectApplied(instance, effectId) {
  if (!isStableId(effectId)) return { changed: false, reason: "invalid-effect-id", instance };
  if ((instance.appliedEffectIds ?? []).includes(effectId)) return { changed: false, reason: "duplicate-effect", instance };
  return { changed: true, instance: { ...instance, appliedEffectIds: [...(instance.appliedEffectIds ?? []), effectId].slice(-500) } };
}
