import { farmV1Pack } from "./farm-v1.mjs";
import { highSchoolV1Pack } from "./high-school-v1.mjs";

const objective = (id, type, target) => ({ id, type, target, requiredCount: 1, progressMode: "increment" });
const quest = (themeId, id, title, summary, type, target) => ({
  id: `${themeId}.${id}`,
  schemaVersion: 1,
  themeId,
  title,
  summary,
  description: summary,
  kind: "side",
  objectives: [objective("first-step", type, target)],
  completionPolicy: "all",
  visibilityPolicy: "visible",
  repeatPolicy: "once",
  contentVersion: "0.1.0",
});

export const builtInThemePacks = Object.freeze([
  {
    metadata: { id: "auto", name: "자동 선택", version: "0.1.0", description: "RP 단서를 바탕으로 안전하게 테마를 추천합니다.", compatibleEngineVersion: "2.4.4" },
    vocabulary: { quest: "퀘스트", activity: "활동", season: "시기" },
    detection: { tags: [] },
    quests: [],
  },
  farmV1Pack,
  highSchoolV1Pack,
  {
    metadata: { id: "fantasy", name: "판타지", version: "0.1.0", description: "길드, 탐험, 마법과 왕국 의뢰를 위한 테마입니다.", compatibleEngineVersion: "2.4.4" },
    vocabulary: { quest: "모험", activity: "행동", season: "시기" },
    detection: { tags: ["fantasy", "guild", "magic", "monster", "kingdom", "dungeon", "마법", "길드", "몬스터", "왕국"] },
    quests: [quest("fantasy", "guild-step", "길드의 첫 의뢰", "길드 활동 하나를 마친다.", "activityCompleted", "guild-task")],
  },
  {
    metadata: { id: "slice-of-life", name: "일상", version: "0.1.0", description: "취미, 이웃, 직장과 소소한 관계 활동을 위한 테마입니다.", compatibleEngineVersion: "2.4.4" },
    vocabulary: { quest: "할 일", activity: "일상", season: "시기" },
    detection: { tags: ["slice-of-life", "daily", "hobby", "neighbor", "home", "workplace", "일상", "취미", "이웃", "직장"] },
    quests: [quest("slice-of-life", "small-kindness", "작은 친절", "일상에서 작은 도움을 건넨다.", "npcInteraction", "help")],
  },
  {
    metadata: { id: "custom", name: "사용자 정의", version: "0.1.0", description: "검증된 사용자 정의 콘텐츠를 담는 안전한 기본 테마입니다.", compatibleEngineVersion: "2.4.4" },
    vocabulary: { quest: "퀘스트", activity: "활동", season: "시기" },
    detection: { tags: [] },
    quests: [],
  },
]);
