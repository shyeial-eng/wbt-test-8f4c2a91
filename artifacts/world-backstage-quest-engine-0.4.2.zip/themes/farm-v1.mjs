const quest = (input) => ({
  schemaVersion: 1,
  themeId: "farm",
  description: input.summary,
  completionPolicy: "all",
  visibilityPolicy: "visible",
  repeatPolicy: "once",
  contentVersion: "1.0.0",
  prerequisites: [],
  rewards: [],
  consequences: [],
  ...input,
});

export const farmV1Pack = Object.freeze({
  metadata: {
    id: "farm",
    name: "농장",
    version: "1.0.0",
    description: "NPC 의뢰, 동물 돌봄, 날씨 기회와 수확제를 포함한 Farm V1 테마입니다.",
    compatibleEngineVersion: "2.4.4",
  },
  vocabulary: { quest: "의뢰", activity: "농장일", season: "계절" },
  detection: { tags: ["farm", "crop", "harvest", "barn", "livestock", "village", "농장", "작물", "수확", "가축"] },
  npcs: [
    { id: "farm.npc.mira", name: "미라", roles: ["quest-giver", "participant"], description: "마을과 농장을 오가며 씨앗을 관리하는 이웃입니다." },
  ],
  locations: [
    { id: "farm.old-barn", name: "오래된 헛간" },
    { id: "farm.riverside-field", name: "강가 밭" },
    { id: "farm.village-square", name: "마을 광장" },
  ],
  activities: [
    { id: "farm.plant-seeds", name: "씨앗 심기" },
    { id: "farm.care-animal", name: "동물 돌보기" },
    { id: "farm.prepare-festival", name: "수확제 준비" },
  ],
  quests: [
    quest({
      id: "farm.mira-seed-baskets",
      title: "미라의 씨앗 바구니",
      summary: "미라가 잃어버린 씨앗 바구니 두 개를 찾아 돌려준다.",
      kind: "npc",
      giverNpcId: "farm.npc.mira",
      objectives: [{ id: "find-baskets", title: "씨앗 바구니 2개 찾기", type: "itemAcquired", target: "farm.seed-basket", requiredCount: 2, progressMode: "increment" }],
      rewards: [
        { id: "farm.mira-seed-baskets.reward-trust", type: "relationship", target: "farm.npc.mira", amount: 1 },
        { id: "farm.mira-seed-baskets.reward-followup", type: "revealQuest", target: "farm.spring-planting" },
      ],
      repeatPolicy: "cooldown",
      epilogue: { text: "다음 날 미라는 가지런히 정리한 씨앗 꾸러미와 짧은 감사 쪽지를 건넨다.", deliveryPolicy: "next-turn" },
    }),
    quest({
      id: "farm.spring-planting",
      title: "봄밭의 첫 줄",
      summary: "강가 밭에 봄 씨앗을 심는다.",
      kind: "seasonal",
      prerequisites: [{ field: "state.season", operator: "eq", value: "spring" }],
      objectives: [{ id: "plant-row", title: "봄 씨앗 한 줄 심기", type: "activityCompleted", target: "farm.plant-seeds", requiredCount: 1, progressMode: "increment" }],
      rewards: [{ id: "farm.spring-planting.reward-ready", type: "flag", key: "springFieldReady", value: true }],
      repeatPolicy: "perSeason",
    }),
    quest({
      id: "farm.gentle-hands",
      title: "다정한 손길",
      summary: "며칠 동안 동물들을 세심하게 돌봐 신뢰를 얻는다.",
      kind: "secret",
      visibilityPolicy: "hidden",
      objectives: [{ id: "care-three-times", title: "동물 돌봄 3회", type: "activityCompleted", target: "farm.care-animal", requiredCount: 3, progressMode: "increment", visibility: "hidden" }],
      rewards: [{ id: "farm.gentle-hands.reward-trust", type: "flag", key: "animalsTrustPlayer", value: true }],
    }),
    quest({
      id: "farm.harvest-festival-help",
      title: "수확제 준비",
      summary: "마을 광장의 수확제 준비를 돕는다.",
      kind: "event",
      objectives: [{ id: "festival-prep", title: "수확제 준비 2회", type: "activityCompleted", target: "farm.prepare-festival", requiredCount: 2, progressMode: "increment" }],
      rewards: [{ id: "farm.harvest-festival-help.reward-memory", type: "flag", key: "helpedHarvestFestival", value: true }],
      repeatPolicy: "perEvent",
    }),
  ],
  opportunities: [
    {
      id: "farm.rain-cleared-soil",
      questDefinitionId: "farm.spring-planting",
      reason: "비가 갠 뒤 강가 밭의 흙이 부드러워졌다.",
      trigger: { eventType: "locationVisited", target: "farm.riverside-field", conditions: [{ field: "state.weather", operator: "eq", value: "after-rain" }] },
      confidence: 1,
      cooldownHours: 24,
    },
  ],
  secretRules: [
    { questDefinitionId: "farm.gentle-hands", hintAfterProgress: 1, revealAfterProgress: 2 },
  ],
  events: [
    {
      id: "farm.harvest-festival",
      title: "수확제",
      startsAt: "2026-09-01T00:00:00.000Z",
      endsAt: "2026-09-03T00:00:00.000Z",
      questDefinitionIds: ["farm.harvest-festival-help"],
      expirationPolicy: "expired",
    },
  ],
});

export function getFarmQuest(id) {
  return farmV1Pack.quests.find((entry) => entry.id === id) ?? null;
}
