const quest = (input) => ({ schemaVersion: 1, themeId: "high-school", description: input.summary, completionPolicy: "all", visibilityPolicy: "visible", repeatPolicy: "once", contentVersion: "1.0.0", prerequisites: [], rewards: [], consequences: [], ...input });

export const highSchoolV1Pack = Object.freeze({
  metadata: { id: "high-school", name: "고등학교", version: "1.0.0", description: "동아리 의뢰, 방과 후 기회, 관계 비밀 퀘스트와 학교 행사를 포함한 High School V1 테마입니다.", compatibleEngineVersion: "2.4.4" },
  vocabulary: { quest: "과제", activity: "학교 활동", season: "학기" },
  detection: { tags: ["school", "class", "club", "exam", "teacher", "student", "학교", "수업", "동아리", "시험"] },
  npcs: [{ id: "high-school.npc.sora", name: "소라", roles: ["quest-giver", "participant"], description: "방송부 부장으로 학교 축제 준비를 맡고 있습니다." }],
  locations: [{ id: "high-school.broadcast-room", name: "방송실" }, { id: "high-school.library", name: "도서관" }, { id: "high-school.gym", name: "체육관" }],
  activities: [{ id: "high-school.collect-interview", name: "인터뷰 자료 모으기" }, { id: "high-school.study-together", name: "함께 공부하기" }, { id: "high-school.prepare-festival", name: "학교 축제 준비" }],
  quests: [
    quest({
      id: "high-school.sora-broadcast-request", title: "소라의 방송부 부탁", summary: "축제 방송에 사용할 인터뷰 자료 두 개를 모아 소라에게 전달한다.", kind: "npc", giverNpcId: "high-school.npc.sora",
      objectives: [{ id: "collect-interviews", title: "인터뷰 자료 2개 모으기", type: "activityCompleted", target: "high-school.collect-interview", requiredCount: 2, progressMode: "increment" }],
      rewards: [{ id: "high-school.sora-broadcast-request.reward-trust", type: "relationship", target: "high-school.npc.sora", amount: 1 }, { id: "high-school.sora-broadcast-request.reward-festival", type: "revealQuest", target: "high-school.festival-broadcast" }],
      repeatPolicy: "cooldown", epilogue: { text: "다음 날 점심 방송에서 소라는 이름을 밝히지 않은 채 도움을 준 친구에게 감사 인사를 전한다.", deliveryPolicy: "next-turn" },
    }),
    quest({
      id: "high-school.after-school-study", title: "방과 후 공부 모임", summary: "도서관에서 친구들과 시험 공부를 마친다.", kind: "opportunity",
      objectives: [{ id: "study-session", title: "방과 후 공부 1회", type: "activityCompleted", target: "high-school.study-together", requiredCount: 1, progressMode: "increment" }],
      rewards: [{ id: "high-school.after-school-study.reward-ready", type: "flag", key: "examStudyComplete", value: true }], repeatPolicy: "cooldown",
    }),
    quest({
      id: "high-school.unspoken-support", title: "말하지 못한 응원", summary: "소라가 숨겨 둔 고민을 듣고 조용히 힘이 되어 준다.", kind: "secret", visibilityPolicy: "hidden",
      prerequisites: [{ field: "state.relationship", operator: "gte", value: 3 }],
      objectives: [{ id: "listen-sora", title: "소라의 고민 들어주기", type: "npcInteraction", target: "high-school.npc.sora", requiredCount: 1, progressMode: "boolean", visibility: "hidden" }],
      rewards: [{ id: "high-school.unspoken-support.reward-bond", type: "flag", key: "soraTrustsPlayer", value: true }],
    }),
    quest({
      id: "high-school.festival-broadcast", title: "축제 생방송", summary: "학교 축제 생방송 준비를 두 번 돕는다.", kind: "event",
      objectives: [{ id: "broadcast-prep", title: "축제 방송 준비 2회", type: "activityCompleted", target: "high-school.prepare-festival", requiredCount: 2, progressMode: "increment" }],
      rewards: [{ id: "high-school.festival-broadcast.reward-memory", type: "flag", key: "helpedSchoolFestival", value: true }], repeatPolicy: "perEvent",
    }),
  ],
  opportunities: [{ id: "high-school.library-study-offer", questDefinitionId: "high-school.after-school-study", reason: "방과 후 도서관에 작은 공부 모임이 열렸다.", trigger: { eventType: "locationVisited", target: "high-school.library", conditions: [{ field: "state.timePeriod", operator: "eq", value: "after-school" }] }, confidence: 1, expiresAfterMinutes: 120 }],
  secretRules: [{ questDefinitionId: "high-school.unspoken-support", hintRelationship: 2, revealRelationship: 3 }],
  events: [
    { id: "high-school.midterm-week", title: "중간고사 기간", startsAt: "2026-10-12T00:00:00.000Z", endsAt: "2026-10-17T00:00:00.000Z", questDefinitionIds: ["high-school.after-school-study"], expirationPolicy: "expired" },
    { id: "high-school.festival", title: "학교 축제", startsAt: "2026-11-01T00:00:00.000Z", endsAt: "2026-11-03T00:00:00.000Z", questDefinitionIds: ["high-school.festival-broadcast"], expirationPolicy: "expired" },
  ],
});

export function getHighSchoolQuest(id) { return highSchoolV1Pack.quests.find((entry) => entry.id === id) ?? null; }
