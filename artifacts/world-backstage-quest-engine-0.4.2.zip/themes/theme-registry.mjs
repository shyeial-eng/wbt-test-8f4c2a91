import { validateQuestDefinition, validateThemePack } from "../domain/quest-domain.mjs";
import { builtInThemePacks } from "./built-in-packs.mjs";

function clone(value) {
  return structuredClone(value);
}

function normalizeTags(value) {
  return Array.isArray(value)
    ? [...new Set(value.filter((tag) => typeof tag === "string").map((tag) => tag.trim().toLowerCase()).filter(Boolean))].slice(0, 100)
    : [];
}

export function createThemeRegistry(initialPacks = builtInThemePacks) {
  const packs = new Map();

  function register(pack, options = {}) {
    const validation = validateThemePack(pack);
    if (!validation.valid) return { registered: false, reason: "invalid-pack", issues: validation.issues };
    const id = pack.metadata.id;
    if (packs.has(id) && options.override !== true) return { registered: false, reason: "duplicate-theme-id", issues: [] };
    packs.set(id, clone(pack));
    return { registered: true, id };
  }

  for (const pack of initialPacks) {
    const result = register(pack);
    if (!result.registered) throw new TypeError(`내장 테마 팩이 유효하지 않습니다: ${pack?.metadata?.id ?? "unknown"}`);
  }

  return {
    register,
    get(id) { return packs.has(id) ? clone(packs.get(id)) : null; },
    has(id) { return packs.has(id); },
    list() { return [...packs.values()].map((pack) => clone(pack)); },
  };
}

export function chooseTheme(context, registry, options = {}) {
  const tags = normalizeTags([...(context?.tags ?? []), ...(context?.worldTags ?? []), context?.setting]);
  const candidates = registry.list()
    .filter((pack) => !["auto", "custom"].includes(pack.metadata.id))
    .map((pack) => {
      const detectionTags = normalizeTags(pack.detection?.tags);
      const matchedTags = detectionTags.filter((tag) => tags.includes(tag));
      return { themeId: pack.metadata.id, score: matchedTags.length, matchedTags };
    })
    .sort((a, b) => b.score - a.score || a.themeId.localeCompare(b.themeId));
  const best = candidates[0];
  const second = candidates[1];
  const minimumScore = Number.isInteger(options.minimumScore) ? options.minimumScore : 1;
  if (!best || best.score < minimumScore) return { themeId: "custom", confidence: 0, reason: "insufficient-evidence", candidates };
  if (second && second.score === best.score) return { themeId: "custom", confidence: 0, reason: "ambiguous-evidence", candidates };
  const confidence = Math.min(1, best.score / Math.max(minimumScore + 1, 2));
  return { themeId: best.themeId, confidence, reason: "matched-tags", matchedTags: best.matchedTags, candidates };
}

export function loadCustomThemePack(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return { loaded: false, reason: "invalid-pack", issues: [{ path: "theme", message: "테마 팩은 객체여야 합니다." }], pack: null, quarantined: [] };
  const metadata = value.metadata;
  const shell = validateThemePack({ ...value, quests: [] });
  if (!shell.valid) return { loaded: false, reason: "invalid-metadata", issues: shell.issues, pack: null, quarantined: [] };
  if (["auto", "farm", "high-school", "fantasy", "slice-of-life"].includes(metadata.id)) {
    return { loaded: false, reason: "reserved-theme-id", issues: [{ path: "metadata.id", message: "내장 테마 ID는 덮어쓸 수 없습니다." }], pack: null, quarantined: [] };
  }
  const quests = [];
  const quarantined = [];
  const seen = new Set();
  for (const [index, quest] of (Array.isArray(value.quests) ? value.quests : []).entries()) {
    const validation = validateQuestDefinition(quest);
    const duplicate = typeof quest?.id === "string" && seen.has(quest.id);
    const wrongTheme = quest?.themeId !== metadata.id;
    if (!validation.valid || duplicate || wrongTheme) {
      quarantined.push({ index, id: typeof quest?.id === "string" ? quest.id.slice(0, 120) : null, reasons: [
        ...validation.issues.map((issue) => `${issue.path}: ${issue.message}`),
        ...(duplicate ? ["중복된 퀘스트 ID입니다."] : []),
        ...(wrongTheme ? ["themeId가 테마 팩 ID와 다릅니다."] : []),
      ] });
      continue;
    }
    seen.add(quest.id);
    quests.push(clone(quest));
  }
  return { loaded: true, pack: { ...clone(value), quests }, quarantined, issues: [] };
}
