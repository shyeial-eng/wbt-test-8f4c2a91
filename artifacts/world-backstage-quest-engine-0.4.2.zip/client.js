const TAG = "marinara-capability-wbt-quest-engine";
const TABS = [
  ["now", "지금"], ["quests", "퀘스트"], ["opportunities", "기회"], ["events", "이벤트"], ["history", "기록"],
];

const styles = `
  :host{display:block;color:var(--foreground);font-family:inherit}.wqe-shell{border:1px solid var(--border);border-radius:.85rem;background:color-mix(in srgb,var(--background) 96%,transparent);overflow:hidden;min-width:0}.wqe-head{display:flex;align-items:center;justify-content:space-between;gap:.5rem;padding:.65rem .75rem;border-bottom:1px solid var(--border)}.wqe-title{font-size:.78rem;font-weight:750}.wqe-meta{font-size:.62rem;color:var(--muted-foreground)}.wqe-tabs{display:flex;gap:.2rem;overflow-x:auto;padding:.4rem;border-bottom:1px solid var(--border)}.wqe-tab{border:0;border-radius:.45rem;background:transparent;color:var(--muted-foreground);padding:.45rem .6rem;white-space:nowrap;cursor:pointer;font-size:.68rem}.wqe-tab[aria-selected="true"]{background:var(--secondary);color:var(--foreground);font-weight:700}.wqe-panel{padding:.55rem;max-height:min(32rem,65vh);overflow:auto}.wqe-card{border:1px solid var(--border);border-radius:.65rem;padding:.65rem;margin:.4rem 0;background:color-mix(in srgb,var(--secondary) 42%,transparent)}.wqe-card h4{margin:0 0 .3rem;font-size:.73rem}.wqe-card p,.wqe-empty,.wqe-status{margin:.25rem 0;font-size:.67rem;line-height:1.5;overflow-wrap:anywhere}.wqe-objectives{margin:.4rem 0 0;padding-left:1.1rem;font-size:.65rem}.wqe-actions{display:flex;flex-wrap:wrap;gap:.3rem;margin-top:.5rem}.wqe-action{border:1px solid var(--border);border-radius:.4rem;background:var(--secondary);color:var(--foreground);padding:.35rem .5rem;cursor:pointer;font-size:.64rem}.wqe-error{margin:.5rem;padding:.55rem;border:1px solid color-mix(in srgb,#ef4444 55%,var(--border));border-radius:.55rem;color:#ef4444;font-size:.67rem}.wqe-toolbar{display:inline-flex}.wqe-launcher{border:1px solid var(--border);border-radius:.45rem;background:var(--secondary);color:var(--foreground);min-height:2rem;padding:.35rem .55rem;cursor:pointer}.wqe-popover{position:fixed;z-index:10030;width:min(38rem,calc(100vw - 1rem));max-height:calc(100vh - 1rem);overflow:auto;box-shadow:0 18px 45px rgba(0,0,0,.35)}@media(max-width:767px){.wqe-popover{left:.5rem!important;right:.5rem;width:auto}.wqe-tab{padding:.45rem .5rem}.wqe-panel{max-height:70vh}}@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important}}
`;

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = typeof text === "string" ? text : String(text ?? "");
  return node;
}

class WbtQuestEngineElement extends HTMLElement {
  capabilityProps = {};
  viewModel = null;
  activeTab = "now";
  popover = null;
  lastChatId = null;
  onProps = () => this.receiveProps();
  connectedCallback() { this.addEventListener("marinara-capability-props", this.onProps); this.receiveProps(); }
  disconnectedCallback() { this.removeEventListener("marinara-capability-props", this.onProps); this.closePopover(); }
  receiveProps() {
    const chatId = this.capabilityProps?.chatId;
    if (!chatId || this.capabilityProps?.chatMode !== "roleplay") { this.lastChatId = null; this.viewModel = null; this.render(); return; }
    if (this.capabilityProps?.questViewModel) this.viewModel = this.capabilityProps.questViewModel;
    if (this.viewModel?.activeTab && TABS.some(([id]) => id === this.viewModel.activeTab)) this.activeTab = this.viewModel.activeTab;
    if (chatId !== this.lastChatId || this.capabilityProps?.trackerRetryBusy === false) { this.lastChatId = chatId; void this.refresh(); }
    this.render();
  }
  async refresh() {
    const chatId = this.capabilityProps?.chatId; if (!chatId) return;
    try { const response = await fetch(`/api/world-backstage-quest-engine/view/${encodeURIComponent(chatId)}`, { credentials: "same-origin" }); if (!response.ok) throw new Error(`조회 실패 (${response.status})`); this.viewModel = await response.json(); }
    catch (error) { this.viewModel = { ...(this.viewModel ?? {}), runtimeError: error instanceof Error ? error.message : String(error) }; }
    if (this.isConnected) this.render();
  }
  async command(action, key) {
    const chatId = this.capabilityProps?.chatId; if (!chatId) return;
    try {
      const response = await fetch(`/api/world-backstage-quest-engine/command/${encodeURIComponent(chatId)}`, { method: "POST", credentials: "same-origin", headers: { "content-type": "application/json" }, body: JSON.stringify({ action, key, expectedRevision: this.viewModel?.revision }) });
      if (!response.ok) throw new Error(`명령 실패 (${response.status})`);
      this.viewModel = await response.json();
    } catch (error) { this.viewModel = { ...(this.viewModel ?? {}), runtimeError: error instanceof Error ? error.message : String(error) }; }
    if (this.isConnected) this.render();
  }
  closePopover() { this.popover?.remove(); this.popover = null; }
  selectTab(id, focus = false) {
    this.activeTab = id;
    const target = this.popover ?? this;
    this.renderShell(target, this.viewModel);
    if (focus) target.querySelector(`[role="tab"][data-tab="${id}"]`)?.focus();
    this.command("select-tab", id);
  }
  onTabKey(event) {
    const index = TABS.findIndex(([id]) => id === this.activeTab);
    let next = index;
    if (event.key === "ArrowRight") next = (index + 1) % TABS.length;
    else if (event.key === "ArrowLeft") next = (index - 1 + TABS.length) % TABS.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = TABS.length - 1;
    else return;
    event.preventDefault(); this.selectTab(TABS[next][0], true);
  }
  appendCard(parent, card, kind) {
    const article = el("article", "wqe-card"); article.tabIndex = 0;
    article.append(el("h4", "", card.title));
    const detail = card.summary || card.reason || card.period || card.epilogue;
    if (detail) article.append(el("p", "", detail));
    const status = card.status || card.outcome;
    if (status) article.append(el("p", "wqe-status", `상태: ${status}`));
    if (Array.isArray(card.objectives) && card.objectives.length) {
      const list = el("ul", "wqe-objectives");
      for (const objective of card.objectives) list.append(el("li", "", `${objective.completed ? "완료" : "진행 중"} · ${objective.title}`));
      article.append(list);
    }
    if (kind === "opportunity" && ["new", "viewed"].includes(card.status)) {
      const actions = el("div", "wqe-actions");
      const accept = el("button", "wqe-action", "수락"); accept.type = "button"; accept.onclick = () => this.command("accept-opportunity", card.key);
      const dismiss = el("button", "wqe-action", "관심 없음"); dismiss.type = "button"; dismiss.onclick = () => this.command("dismiss-opportunity", card.key);
      actions.append(accept, dismiss); article.append(actions);
    }
    parent.append(article);
  }
  panelItems(model) {
    if (this.activeTab === "now") return [...(model.now?.quests ?? []).map((card) => [card, "quest"]), ...(model.now?.opportunities ?? []).map((card) => [card, "opportunity"]), ...(model.now?.events ?? []).map((card) => [card, "event"])];
    const map = { quests: "quest", opportunities: "opportunity", events: "event", history: "history" };
    return (model[this.activeTab] ?? []).map((card) => [card, map[this.activeTab]]);
  }
  renderShell(parent, model) {
    parent.replaceChildren(); const style = el("style"); style.textContent = styles; parent.append(style);
    const shell = el("section", "wqe-shell"); shell.setAttribute("aria-label", "WBT 퀘스트 엔진");
    const head = el("header", "wqe-head"); head.append(el("strong", "wqe-title", "🧭 RP 퀘스트"), el("span", "wqe-meta", model?.saving ? "저장 중…" : `테마: ${model?.selectedTheme ?? "선택 안 됨"}`)); shell.append(head);
    if (model?.saveError) { const error = el("p", "wqe-error", `저장 오류: ${model.saveError}`); error.setAttribute("role", "alert"); shell.append(error); }
    if (model?.runtimeError) { const error = el("p", "wqe-error", `실행 오류: ${model.runtimeError}`); error.setAttribute("role", "alert"); shell.append(error); }
    const tabs = el("div", "wqe-tabs"); tabs.setAttribute("role", "tablist"); tabs.setAttribute("aria-label", "퀘스트 보기");
    for (const [id, label] of TABS) {
      const button = el("button", "wqe-tab", label); button.type = "button"; button.dataset.tab = id; button.setAttribute("role", "tab"); button.setAttribute("aria-selected", String(this.activeTab === id)); button.tabIndex = this.activeTab === id ? 0 : -1; button.onclick = () => this.selectTab(id); button.onkeydown = (event) => this.onTabKey(event); tabs.append(button);
    }
    shell.append(tabs);
    const panel = el("div", "wqe-panel"); panel.setAttribute("role", "tabpanel"); panel.setAttribute("aria-label", TABS.find(([id]) => id === this.activeTab)?.[1] ?? "내용");
    const entries = model ? this.panelItems(model) : [];
    if (!entries.length) panel.append(el("p", "wqe-empty", model ? "표시할 내용이 없습니다." : "퀘스트 정보를 기다리는 중입니다."));
    else for (const [card, kind] of entries) this.appendCard(panel, card, kind);
    shell.append(panel); parent.append(shell);
  }
  openPopover(anchor) {
    this.closePopover(); const popover = el("div", "wqe-popover"); popover.setAttribute("data-chat-floating-panel", ""); document.body.append(popover); this.popover = popover; this.renderShell(popover, this.viewModel);
    const rect = anchor.getBoundingClientRect(); const width = popover.offsetWidth; const height = popover.offsetHeight; popover.style.left = `${Math.max(8, Math.min(rect.left, innerWidth - width - 8))}px`; popover.style.top = `${Math.max(8, Math.min(rect.bottom + 5, innerHeight - height - 8))}px`;
  }
  render() {
    this.replaceChildren(); const style = el("style"); style.textContent = styles; this.append(style);
    if (this.getAttribute("view") === "toolbar") { const wrap = el("span", "wqe-toolbar"); const button = el("button", "wqe-launcher", "🧭 퀘스트"); button.type = "button"; button.setAttribute("aria-label", "WBT 퀘스트 열기"); button.onclick = () => this.popover ? this.closePopover() : this.openPopover(button); wrap.append(button); this.append(wrap); }
    else this.renderShell(this, this.viewModel);
  }
}

if (!customElements.get(TAG)) customElements.define(TAG, WbtQuestEngineElement);
