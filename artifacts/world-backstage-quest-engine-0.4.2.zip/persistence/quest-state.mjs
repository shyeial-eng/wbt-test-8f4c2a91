import { createHash } from "node:crypto";
import { isStableId } from "../domain/quest-domain.mjs";

export const QUEST_STATE_SCHEMA_VERSION = 3;
export const QUEST_STATE_LIMITS = Object.freeze({
  questInstances: 250,
  opportunities: 150,
  secretStates: 250,
  historyRecords: 500,
  processedEventIds: 1000,
  appliedEffectIds: 1000,
  quarantinedItems: 100,
});

function object(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function string(value, length = 160) {
  return typeof value === "string" ? value.slice(0, length) : "";
}

function iso(value) {
  return typeof value === "string" && !Number.isNaN(Date.parse(value)) ? value : null;
}

function uniqueStableIds(value, limit) {
  return Array.isArray(value) ? [...new Set(value.filter(isStableId))].slice(-limit) : [];
}

function quarantine(kind, index, reason, value) {
  const identifier = string(object(value).instanceId || object(value).opportunityId || object(value).recordId || object(value).definitionId, 120);
  return { kind, index, identifier: identifier || null, reason };
}

function normalizeProgress(value) {
  const result = {};
  for (const [key, entry] of Object.entries(object(value)).slice(0, 100)) {
    if (!isStableId(key)) continue;
    const source = object(entry);
    result[key] = {
      value: Number.isFinite(source.value) ? source.value : 0,
      completed: source.completed === true,
      ...(Array.isArray(source.checked) ? { checked: [...new Set(source.checked.filter((item) => typeof item === "string").map((item) => item.slice(0, 120)))].slice(0, 100) } : {}),
    };
  }
  return result;
}

function normalizeInstance(value) {
  const source = object(value);
  if (!isStableId(source.instanceId) || !isStableId(source.definitionId)) return null;
  const allowedStatuses = new Set(["available", "offered", "accepted", "active", "blocked", "completed", "failed", "expired", "archived"]);
  if (!allowedStatuses.has(source.status)) return null;
  return {
    instanceId: source.instanceId,
    definitionId: source.definitionId,
    definitionVersion: string(source.definitionVersion, 40) || "1",
    status: source.status,
    objectiveProgress: normalizeProgress(source.objectiveProgress),
    discoveredAt: iso(source.discoveredAt),
    offeredAt: iso(source.offeredAt),
    acceptedAt: iso(source.acceptedAt),
    updatedAt: iso(source.updatedAt),
    completedAt: iso(source.completedAt),
    runtimeFlags: object(source.runtimeFlags),
    appliedEventIds: uniqueStableIds(source.appliedEventIds, 500),
    appliedEffectIds: uniqueStableIds(source.appliedEffectIds, 500),
    snapshot: { title: string(source.snapshot?.title, 200), summary: string(source.snapshot?.summary, 500) },
  };
}

function normalizeOpportunity(value) {
  const source = object(value);
  if (!isStableId(source.opportunityId) || !["new", "viewed", "accepted", "dismissed", "expired"].includes(source.status)) return null;
  return {
    opportunityId: source.opportunityId,
    questDefinitionId: isStableId(source.questDefinitionId) ? source.questDefinitionId : null,
    source: string(source.source, 120),
    reason: string(source.reason, 500),
    confidence: Number.isFinite(source.confidence) ? Math.max(0, Math.min(1, source.confidence)) : null,
    createdAt: iso(source.createdAt),
    expiresAt: iso(source.expiresAt),
    status: source.status,
    viewedAt: iso(source.viewedAt),
    resolvedAt: iso(source.resolvedAt),
  };
}

function normalizeSecretState(value) {
  const source = object(value);
  if (!isStableId(source.definitionId) || !["hidden", "hinted", "revealed"].includes(source.visibility)) return null;
  return { definitionId: source.definitionId, visibility: source.visibility, hintedAt: iso(source.hintedAt), revealedAt: iso(source.revealedAt) };
}

function normalizeHistory(value) {
  const source = object(value);
  if (!isStableId(source.recordId) || !isStableId(source.instanceId) || !isStableId(source.definitionId)) return null;
  if (!["completed", "failed", "expired"].includes(source.outcome)) return null;
  return {
    recordId: source.recordId,
    instanceId: source.instanceId,
    definitionId: source.definitionId,
    definitionVersion: string(source.definitionVersion, 40) || "1",
    outcome: source.outcome,
    occurredAt: iso(source.occurredAt),
    snapshot: { title: string(source.snapshot?.title, 200), summary: string(source.snapshot?.summary, 500) },
    appliedEffectIds: uniqueStableIds(source.appliedEffectIds, 500),
    epilogue: {
      text: string(source.epilogue?.text, 2000),
      deliveryPolicy: ["immediate", "next-turn", "npc-reunion", "history-only"].includes(source.epilogue?.deliveryPolicy) ? source.epilogue.deliveryPolicy : "history-only",
      delivered: source.epilogue?.delivered === true,
      deliveredAt: iso(source.epilogue?.deliveredAt),
    },
  };
}

export function emptyQuestState(chatId, now = new Date().toISOString()) {
  return {
    stateSchemaVersion: QUEST_STATE_SCHEMA_VERSION,
    chatId: string(chatId),
    selectedTheme: null,
    questInstances: [],
    opportunities: [],
    secretStates: [],
    historyRecords: [],
    processedEventIds: [],
    appliedEffectIds: [],
    eventState: {},
    uiPreferences: { activeTab: "now" },
    quarantinedItems: [],
    createdAt: now,
    updatedAt: now,
  };
}

export function migrateQuestState(value, chatId, now = new Date().toISOString()) {
  const source = object(value);
  const version = Number.isInteger(source.stateSchemaVersion) ? source.stateSchemaVersion : 0;
  if (version > QUEST_STATE_SCHEMA_VERSION) return { supported: false, reason: "future-schema", value: emptyQuestState(chatId, now) };
  if (version === 0) {
    return { supported: true, migratedFrom: 0, value: { ...source, stateSchemaVersion: 3, questInstances: source.quests ?? source.questInstances ?? [], historyRecords: source.history ?? source.historyRecords ?? [] } };
  }
  if (version === 1) {
    return { supported: true, migratedFrom: 1, value: { ...source, stateSchemaVersion: 3, processedEventIds: source.processedEvents ?? source.processedEventIds ?? [], appliedEffectIds: source.effectsApplied ?? source.appliedEffectIds ?? [] } };
  }
  if (version === 2) {
    return { supported: true, migratedFrom: 2, value: { ...source, stateSchemaVersion: 3, secretStates: source.secretStates ?? [] } };
  }
  return { supported: true, migratedFrom: null, value: source };
}

export function normalizeQuestState(value, chatId, now = new Date().toISOString()) {
  const migration = migrateQuestState(value, chatId, now);
  if (!migration.supported) return { ...migration, quarantined: [] };
  const source = object(migration.value);
  const quarantined = [];
  const collect = (items, kind, normalizer, limit) => {
    const output = [];
    for (const [index, item] of (Array.isArray(items) ? items : []).entries()) {
      const normalized = normalizer(item);
      if (normalized) output.push(normalized);
      else quarantined.push(quarantine(kind, index, "invalid-item", item));
    }
    return output.slice(-limit);
  };
  const state = emptyQuestState(chatId, iso(source.createdAt) ?? now);
  state.selectedTheme = isStableId(source.selectedTheme) ? source.selectedTheme : null;
  state.questInstances = collect(source.questInstances, "quest-instance", normalizeInstance, QUEST_STATE_LIMITS.questInstances);
  state.opportunities = collect(source.opportunities, "opportunity", normalizeOpportunity, QUEST_STATE_LIMITS.opportunities);
  state.secretStates = collect(source.secretStates, "secret-state", normalizeSecretState, QUEST_STATE_LIMITS.secretStates);
  state.historyRecords = collect(source.historyRecords, "history-record", normalizeHistory, QUEST_STATE_LIMITS.historyRecords);
  state.processedEventIds = uniqueStableIds(source.processedEventIds, QUEST_STATE_LIMITS.processedEventIds);
  state.appliedEffectIds = uniqueStableIds(source.appliedEffectIds, QUEST_STATE_LIMITS.appliedEffectIds);
  state.eventState = object(source.eventState);
  state.uiPreferences = { activeTab: ["now", "quests", "opportunities", "events", "history"].includes(source.uiPreferences?.activeTab) ? source.uiPreferences.activeTab : "now" };
  state.quarantinedItems = [...(Array.isArray(source.quarantinedItems) ? source.quarantinedItems.filter((item) => item && typeof item === "object") : []), ...quarantined]
    .slice(-QUEST_STATE_LIMITS.quarantinedItems);
  state.updatedAt = iso(source.updatedAt) ?? now;
  return { supported: true, migratedFrom: migration.migratedFrom, value: state, quarantined };
}

export function questStateDocumentId(packageId, chatId) {
  return createHash("sha256").update(`${packageId}\0quest-state\0${chatId}`).digest("hex");
}
