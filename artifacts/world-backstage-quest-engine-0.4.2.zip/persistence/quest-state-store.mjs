import { emptyQuestState, normalizeQuestState, questStateDocumentId } from "./quest-state.mjs";

const DOCUMENT_KIND = "quest-engine-state";

export function createQuestStateStore({ packageId, documents, clock = () => new Date().toISOString(), logger = { warn() {} } }) {
  if (!packageId || !documents) throw new TypeError("packageId와 document store가 필요합니다.");

  async function load(chatId) {
    const id = questStateDocumentId(packageId, chatId);
    const document = await documents.getById(packageId, id);
    if (!document) return { state: emptyQuestState(chatId, clock()), revision: null, migratedFrom: null, quarantined: [] };
    const result = normalizeQuestState(document.data, chatId, clock());
    if (!result.supported) return { state: result.value, revision: document.revision, readOnly: true, reason: result.reason, migratedFrom: null, quarantined: [] };
    return { state: result.value, revision: document.revision, migratedFrom: result.migratedFrom, quarantined: result.quarantined };
  }

  async function save(chatId, state, options = {}) {
    const normalized = normalizeQuestState({ ...state, updatedAt: clock() }, chatId, clock());
    if (!normalized.supported) return { saved: false, reason: normalized.reason, state: normalized.value };
    const id = questStateDocumentId(packageId, chatId);
    const current = await documents.getById(packageId, id);
    if (options.expectedRevision !== undefined && (current?.revision ?? null) !== options.expectedRevision) {
      return { saved: false, reason: "revision-conflict", state: normalized.value, currentRevision: current?.revision ?? null };
    }
    try {
      if (!current) {
        await documents.create({ id, packageId, kind: DOCUMENT_KIND, name: chatId, description: "WBT Quest Engine state", data: normalized.value, createdAt: normalized.value.createdAt, updatedAt: normalized.value.updatedAt });
        return { saved: true, created: true, state: normalized.value };
      }
      const saved = await documents.update({ id, packageId, expectedRevision: current.revision, name: chatId, description: current.description, data: normalized.value, updatedAt: normalized.value.updatedAt });
      if (!saved) return { saved: false, reason: "revision-conflict", state: normalized.value };
      return { saved: true, created: false, state: normalized.value };
    } catch (error) {
      logger.warn("[wbt-quest-engine] State save failed for chat %s: %s", chatId, error instanceof Error ? error.message : String(error));
      return { saved: false, reason: "storage-error", state: normalized.value, error };
    }
  }

  return { load, save };
}
