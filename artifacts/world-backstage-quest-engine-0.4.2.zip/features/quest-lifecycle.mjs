import { createQuestInstance, isStableId, transitionQuest } from "../domain/quest-domain.mjs";

const OPPORTUNITY_TRANSITIONS = Object.freeze({
  new: new Set(["viewed", "accepted", "dismissed", "expired"]),
  viewed: new Set(["accepted", "dismissed", "expired"]),
  accepted: new Set(),
  dismissed: new Set(),
  expired: new Set(),
});
const VISIBILITY_TRANSITIONS = Object.freeze({
  hidden: new Set(["hinted", "revealed"]),
  hinted: new Set(["revealed"]),
  revealed: new Set(),
});

function validIso(value) {
  return typeof value === "string" && !Number.isNaN(Date.parse(value));
}

function clone(value) {
  return structuredClone(value);
}

export function createOpportunity(input, now) {
  if (!isStableId(input?.opportunityId) || !validIso(now)) throw new TypeError("올바른 opportunity ID와 시간이 필요합니다.");
  const confidence = Number.isFinite(input.confidence) ? Math.max(0, Math.min(1, input.confidence)) : null;
  return {
    opportunityId: input.opportunityId,
    source: typeof input.source === "string" ? input.source.slice(0, 120) : "unknown",
    questDefinitionId: isStableId(input.questDefinitionId) ? input.questDefinitionId : null,
    reason: typeof input.reason === "string" ? input.reason.slice(0, 500) : "",
    confidence,
    createdAt: now,
    expiresAt: validIso(input.expiresAt) ? input.expiresAt : null,
    status: "new",
    viewedAt: null,
    resolvedAt: null,
  };
}

export function transitionOpportunity(opportunity, nextStatus, occurredAt) {
  if (!OPPORTUNITY_TRANSITIONS[opportunity?.status] || !OPPORTUNITY_TRANSITIONS[opportunity.status].has(nextStatus)) {
    return { changed: false, reason: "illegal-transition", opportunity };
  }
  const next = { ...opportunity, status: nextStatus };
  if (nextStatus === "viewed") next.viewedAt = occurredAt;
  if (["accepted", "dismissed", "expired"].includes(nextStatus)) next.resolvedAt = occurredAt;
  return { changed: true, opportunity: next };
}

export function acceptOpportunity(opportunity, definition, options) {
  const transition = transitionOpportunity(opportunity, "accepted", options.now);
  if (!transition.changed) return { changed: false, reason: transition.reason, opportunity, instance: null };
  if (opportunity.questDefinitionId !== definition.id) return { changed: false, reason: "definition-mismatch", opportunity, instance: null };
  const instance = createQuestInstance(definition, { instanceId: options.instanceId, status: "accepted", now: options.now });
  instance.originOpportunityId = opportunity.opportunityId;
  return { changed: true, opportunity: transition.opportunity, instance };
}

export function offerQuest(instance, occurredAt, sourceNpcId = null) {
  const result = transitionQuest(instance, "offered", occurredAt);
  if (!result.changed) return result;
  return { ...result, instance: { ...result.instance, sourceNpcId: isStableId(sourceNpcId) ? sourceNpcId : null } };
}

export function declineQuest(instance, occurredAt, policy = {}) {
  if (instance?.status !== "offered") return { changed: false, reason: "not-offered", instance };
  return {
    changed: true,
    instance: {
      ...instance,
      status: "available",
      updatedAt: occurredAt,
      runtimeFlags: { ...instance.runtimeFlags, declinedAt: occurredAt, reofferAfter: validIso(policy.reofferAfter) ? policy.reofferAfter : null },
    },
  };
}

export function canReofferQuest(instance, now) {
  if (instance?.status !== "available") return false;
  const reofferAfter = instance.runtimeFlags?.reofferAfter;
  return !validIso(reofferAfter) || Date.parse(now) >= Date.parse(reofferAfter);
}

export function createSecretState(definition) {
  const initial = definition.visibilityPolicy === "hidden" ? "hidden" : definition.visibilityPolicy === "hinted" ? "hinted" : "revealed";
  return { definitionId: definition.id, visibility: initial, hintedAt: null, revealedAt: null };
}

export function transitionSecretVisibility(secretState, nextVisibility, occurredAt) {
  if (!VISIBILITY_TRANSITIONS[secretState?.visibility]?.has(nextVisibility)) return { changed: false, reason: "illegal-visibility-transition", secretState };
  const next = { ...secretState, visibility: nextVisibility };
  if (nextVisibility === "hinted") next.hintedAt = occurredAt;
  if (nextVisibility === "revealed") next.revealedAt = occurredAt;
  return { changed: true, secretState: next };
}

export function projectSecretQuest(definition, instance, secretState) {
  if (secretState?.visibility === "hidden") return { id: definition.id, visibility: "hidden", title: null, summary: null, objectives: [] };
  if (secretState?.visibility === "hinted") return { id: definition.id, visibility: "hinted", title: "숨겨진 퀘스트", summary: "특별한 사건의 단서가 보입니다.", objectives: [] };
  return {
    id: definition.id,
    visibility: "revealed",
    title: definition.title,
    summary: definition.summary,
    objectives: definition.objectives.filter((objective) => objective.visibility !== "hidden").map((objective) => ({ id: objective.id, completed: instance.objectiveProgress?.[objective.id]?.completed === true })),
  };
}

export function evaluateTimedEvent(definition, eventState, now) {
  const timestamp = Date.parse(now);
  if (!isStableId(definition?.id) || Number.isNaN(timestamp) || !validIso(definition.startsAt) || !validIso(definition.endsAt)) {
    return { changed: false, reason: "invalid-event-definition", eventState, domainEvents: [] };
  }
  const start = Date.parse(definition.startsAt);
  const end = Date.parse(definition.endsAt);
  if (end <= start) return { changed: false, reason: "invalid-event-window", eventState, domainEvents: [] };
  const current = eventState ?? { eventId: definition.id, status: "scheduled", emittedTransitionIds: [] };
  const emitted = new Set(current.emittedTransitionIds ?? []);
  const domainEvents = [];
  let status = current.status;
  const startId = `${definition.id}.started.${definition.startsAt}`.toLowerCase().replace(/[^a-z0-9._-]/g, "-");
  const endId = `${definition.id}.ended.${definition.endsAt}`.toLowerCase().replace(/[^a-z0-9._-]/g, "-");
  if (timestamp >= start && !emitted.has(startId)) {
    emitted.add(startId);
    domainEvents.push({ eventId: startId, type: "seasonalEventStarted", occurredAt: now, target: definition.id });
  }
  if (timestamp >= end && !emitted.has(endId)) {
    emitted.add(endId);
    domainEvents.push({ eventId: endId, type: "seasonalEventEnded", occurredAt: now, target: definition.id });
  }
  if (timestamp < start) status = "scheduled";
  else if (timestamp < end) status = "active";
  else status = "ended";
  const next = { eventId: definition.id, status, emittedTransitionIds: [...emitted], evaluatedAt: now };
  const changed = status !== current.status || domainEvents.length > 0;
  return { changed, eventState: changed ? next : current, domainEvents };
}

export function createHistoryRecord(definition, instance, occurredAt, epilogue = null) {
  if (!["completed", "failed", "expired"].includes(instance?.status)) return { created: false, reason: "non-terminal-instance", record: null };
  const recordId = `${instance.instanceId}.${instance.status}`;
  return {
    created: true,
    record: {
      recordId,
      instanceId: instance.instanceId,
      definitionId: instance.definitionId,
      definitionVersion: instance.definitionVersion,
      outcome: instance.status,
      occurredAt,
      snapshot: { title: instance.snapshot?.title || definition.title, summary: instance.snapshot?.summary || definition.summary },
      appliedEffectIds: [...(instance.appliedEffectIds ?? [])],
      epilogue: { text: typeof epilogue?.text === "string" ? epilogue.text.slice(0, 2000) : "", deliveryPolicy: epilogue?.deliveryPolicy ?? "history-only", delivered: false, deliveredAt: null },
    },
  };
}

export function addHistoryRecord(history, record) {
  if (history.some((entry) => entry.recordId === record.recordId)) return { changed: false, reason: "duplicate-history", history };
  return { changed: true, history: [...history, clone(record)] };
}

export function deliverEpilogue(record, occurredAt) {
  if (!record?.epilogue?.text) return { changed: false, reason: "no-epilogue", record };
  if (record.epilogue.delivered) return { changed: false, reason: "already-delivered", record };
  return { changed: true, record: { ...record, epilogue: { ...record.epilogue, delivered: true, deliveredAt: occurredAt } } };
}
