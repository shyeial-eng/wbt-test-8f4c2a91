const SUPPORTED_ENGINE_VERSION = "2.4.4";

function text(value, limit = 500) {
  return typeof value === "string" ? value.replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, limit) : "";
}

function publicVisibility(definition, secretState) {
  if (definition?.visibilityPolicy === "hidden") return secretState?.visibility === "revealed";
  return secretState?.visibility !== "hidden" && secretState?.visibility !== "hinted";
}

function publicObjectives(definition, instance) {
  return (Array.isArray(definition?.objectives) ? definition.objectives : [])
    .filter((objective) => objective?.visibility !== "hidden")
    .slice(0, 30)
    .flatMap((objective) => {
      const label = text(objective.title || objective.target || objective.type, 160);
      return label ? [{ text: label, completed: instance?.objectiveProgress?.[objective.id]?.completed === true }] : [];
    });
}

function publicRewards(definition) {
  return (Array.isArray(definition?.rewards) ? definition.rewards : []).slice(0, 20).flatMap((reward) => {
    const label = text(reward?.label || reward?.description, 160);
    return label ? [label] : [];
  });
}

export function validateQuestTrackerUpdate(update) {
  if (!update || typeof update !== "object" || Array.isArray(update)) return false;
  if (!["create", "update", "complete", "fail"].includes(update.action)) return false;
  if (!text(update.questName, 200)) return false;
  if (update.objectives !== undefined && (!Array.isArray(update.objectives) || update.objectives.some((objective) => !text(objective?.text, 160) || typeof objective.completed !== "boolean"))) return false;
  if (update.rewards !== undefined && (!Array.isArray(update.rewards) || update.rewards.some((reward) => !text(reward, 160)))) return false;
  return true;
}

export function projectQuestTrackerUpdate({ definition, instance, secretState, published = false }) {
  if (!definition || !instance || !publicVisibility(definition, secretState)) return { projected: false, reason: "not-public", update: null };
  if (["available", "offered", "archived", "expired"].includes(instance.status)) return { projected: false, reason: "not-trackable-status", update: null };
  const questName = `[WBT] ${text(definition.title, 160)}`;
  if (questName === "[WBT] ") return { projected: false, reason: "missing-title", update: null };
  let action = published ? "update" : "create";
  if (instance.status === "completed") action = "complete";
  else if (instance.status === "failed") action = "fail";
  const update = {
    action,
    questName,
    description: text(definition.summary || definition.description, 500),
    objectives: publicObjectives(definition, instance),
    rewards: publicRewards(definition),
    notes: "WBT가 공개 상태만 선택적으로 투영했습니다.",
  };
  return validateQuestTrackerUpdate(update) ? { projected: true, update } : { projected: false, reason: "invalid-projection", update: null };
}

export function createQuestTrackerBridge(options = {}) {
  const enabled = options.enabled === true;
  const engineVersion = text(options.engineVersion, 40);
  const compatible = engineVersion === SUPPORTED_ENGINE_VERSION;
  const publishedDefinitions = new Set(Array.isArray(options.publishedDefinitionIds) ? options.publishedDefinitionIds : []);
  return {
    status: enabled ? (compatible ? "ready" : "incompatible") : "disabled",
    project(input) {
      if (!enabled) return { projected: false, reason: "bridge-disabled", update: null };
      if (!compatible) return { projected: false, reason: "incompatible-engine", update: null };
      const result = projectQuestTrackerUpdate({ ...input, published: publishedDefinitions.has(input?.definition?.id) });
      if (result.projected) publishedDefinitions.add(input.definition.id);
      return result;
    },
    snapshot() { return { enabled, engineVersion, publishedDefinitionIds: [...publishedDefinitions] }; },
  };
}

export function createNoopQuestTrackerBridge() {
  return createQuestTrackerBridge({ enabled: false });
}

export const questTrackerBridgeContract = Object.freeze({ engineVersion: SUPPORTED_ENGINE_VERSION, resultType: "quest_update", actions: ["create", "update", "complete", "fail"] });
