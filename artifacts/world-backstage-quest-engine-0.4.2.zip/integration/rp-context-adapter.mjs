import { isStableId } from "../domain/quest-domain.mjs";
import { normalizeRuntimeEvent } from "../runtime/quest-runtime.mjs";
import { projectSecretQuest } from "../features/quest-lifecycle.mjs";

const MAX_SIGNALS = 30;
const DEFAULT_CONFIDENCE_THRESHOLD = 0.8;

function object(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

function text(value, limit) {
  return typeof value === "string" ? value.replace(/[\u0000-\u001f\u007f]/g, " ").replace(/\s+/g, " ").trim().slice(0, limit) : "";
}

export function extractStructuredSignals(payload, options = {}) {
  const source = object(payload);
  const threshold = Number.isFinite(options.confidenceThreshold) ? Math.max(0, Math.min(1, options.confidenceThreshold)) : DEFAULT_CONFIDENCE_THRESHOLD;
  const acceptedEvents = [];
  const opportunityCandidates = [];
  const rejected = [];
  const seen = new Set();
  for (const [index, signal] of (Array.isArray(source.events) ? source.events : []).slice(0, MAX_SIGNALS).entries()) {
    const candidate = object(signal);
    const confidence = Number.isFinite(candidate.confidence) ? Math.max(0, Math.min(1, candidate.confidence)) : 0;
    const normalized = normalizeRuntimeEvent(candidate);
    if (!normalized.valid) {
      rejected.push({ index, reason: "invalid-event", issues: normalized.issues });
      continue;
    }
    if (seen.has(normalized.event.eventId)) {
      rejected.push({ index, reason: "duplicate-in-payload" });
      continue;
    }
    seen.add(normalized.event.eventId);
    if (confidence < threshold) {
      opportunityCandidates.push({
        candidateId: `${normalized.event.eventId}.candidate`,
        event: normalized.event,
        confidence,
        reason: text(candidate.evidence, 300) || "확신이 낮아 사용자 확인이 필요합니다.",
      });
      continue;
    }
    acceptedEvents.push({ ...normalized.event, confidence, evidence: text(candidate.evidence, 300) });
  }
  return { acceptedEvents, opportunityCandidates, rejected };
}

export function filterUnprocessedEvents(events, processedEventIds) {
  const processed = new Set(Array.isArray(processedEventIds) ? processedEventIds : []);
  const accepted = [];
  const duplicates = [];
  for (const event of events) {
    if (processed.has(event.eventId)) duplicates.push(event.eventId);
    else {
      processed.add(event.eventId);
      accepted.push(event);
    }
  }
  return { accepted, duplicates, processedEventIds: [...processed].slice(-1000) };
}

function visibleQuest(definition, instance, secretState) {
  if (definition.visibilityPolicy === "hidden" || secretState) return projectSecretQuest(definition, instance, secretState ?? { visibility: "hidden" });
  return {
    visibility: "revealed",
    title: definition.title,
    summary: definition.summary,
    objectives: definition.objectives
      .filter((objective) => objective.visibility !== "hidden")
      .map((objective) => ({ title: text(objective.title || objective.target || objective.type, 100), completed: instance.objectiveProgress?.[objective.id]?.completed === true })),
  };
}

function appendWithinBudget(lines, line, budget) {
  const candidate = [...lines, line].join("\n");
  if (candidate.length > budget) return false;
  lines.push(line);
  return true;
}

export function buildRpContextProjection({ state, definitions, secretStates = [], recentChanges = [], pendingEpilogues = [] }, options = {}) {
  const budget = Number.isInteger(options.characterBudget) ? Math.max(200, Math.min(8000, options.characterBudget)) : 2000;
  const definitionsById = new Map((Array.isArray(definitions) ? definitions : []).map((definition) => [definition.id, definition]));
  const secretsById = new Map((Array.isArray(secretStates) ? secretStates : []).map((secret) => [secret.definitionId, secret]));
  const lines = ["[WBT 퀘스트 요약]"];
  const active = (Array.isArray(state?.questInstances) ? state.questInstances : [])
    .filter((instance) => ["accepted", "active", "blocked"].includes(instance.status))
    .sort((a, b) => String(b.updatedAt ?? "").localeCompare(String(a.updatedAt ?? "")));
  for (const instance of active) {
    const definition = definitionsById.get(instance.definitionId);
    if (!definition) continue;
    const projection = visibleQuest(definition, instance, secretsById.get(definition.id));
    if (projection.visibility === "hidden") continue;
    const objectives = projection.objectives.filter((objective) => !objective.completed).slice(0, 3).map((objective) => objective.title || "남은 목표").join(", ");
    const line = `- ${text(projection.title, 120)}${objectives ? `: ${text(objectives, 260)}` : ""}`;
    if (!appendWithinBudget(lines, line, budget)) break;
  }
  for (const change of (Array.isArray(recentChanges) ? recentChanges : []).slice(-3)) {
    const summary = text(change?.summary, 240);
    if (summary && !appendWithinBudget(lines, `- 최근 변화: ${summary}`, budget)) break;
  }
  for (const epilogue of (Array.isArray(pendingEpilogues) ? pendingEpilogues : []).filter((entry) => entry?.delivered !== true).slice(0, 2)) {
    const summary = text(epilogue?.text, 300);
    if (summary && !appendWithinBudget(lines, `- 후일담: ${summary}`, budget)) break;
  }
  if (lines.length === 1) lines.push("- 현재 공개된 활성 퀘스트 변화가 없습니다.");
  return lines.join("\n").slice(0, budget);
}

export function createRpContextAdapter(options = {}) {
  const confidenceThreshold = options.confidenceThreshold ?? DEFAULT_CONFIDENCE_THRESHOLD;
  return {
    prepareContext(input) {
      return { questContext: buildRpContextProjection(input, options) };
    },
    finalizeSignals(payload, state) {
      const extracted = extractStructuredSignals(payload, { confidenceThreshold });
      const filtered = filterUnprocessedEvents(extracted.acceptedEvents, state?.processedEventIds);
      return {
        events: filtered.accepted,
        opportunityCandidates: extracted.opportunityCandidates,
        rejected: extracted.rejected,
        duplicateEventIds: filtered.duplicates,
        processedEventIds: filtered.processedEventIds,
      };
    },
  };
}
